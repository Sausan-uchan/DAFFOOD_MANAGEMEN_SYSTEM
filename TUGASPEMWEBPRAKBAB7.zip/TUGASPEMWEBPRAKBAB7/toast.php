<?php require_once __DIR__ . "/session-start.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pemberitahuan Sistem | DAFFOOD</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="home-page">
    <header class="home-header">
        <a class="home-brand" href="index.php" aria-label="DAFFOOD beranda"><span class="home-brand-mark">D</span>DAFFOOD</a>
        <nav class="home-nav" aria-label="Navigasi utama"><a class="home-login" href="index.php">Beranda DAFFOOD</a><a class="home-register" href="dashboard.php">Dashboard <span aria-hidden="true">↗</span></a></nav>
    </header>
    <main class="demo-main">
        <a class="demo-back" href="index.php#fitur">← Kembali ke Sistem DAFFOOD</a>
        <span class="feature-label toast-label">SISTEM MANAJEMEN DAFFOOD</span>
        <h1>Pemberitahuan aktivitas</h1>
        <p class="demo-description">Pemberitahuan membantu administrator mengetahui hasil tindakan pada pengelolaan menu dan pesanan DAFFOOD.</p>
        <section class="demo-panel" aria-label="Pemberitahuan sistem DAFFOOD">
            <button class="demo-button" id="toast-trigger" type="button">Uji pemberitahuan</button>
            <p class="demo-hint">Pesan sistem tampil sementara dan dapat ditahan dengan mengarahkan pointer ke pemberitahuan.</p>
        </section>
    </main>
    <!-- PENANDA TOAST/SNACKBAR: pesan notifikasi sementara ditampilkan di elemen ini. -->
    <div class="demo-toast" id="demo-toast" role="status" aria-live="polite"></div>
    <script>
        // TUGAS BAB 4 - Event click memunculkan pemberitahuan saat aksi sistem dijalankan.
        const toastTrigger = document.getElementById('toast-trigger');
        const toastMessage = document.getElementById('demo-toast');
        let toastTimer;

        toastTrigger.addEventListener('click', () => {
            toastMessage.textContent = 'Informasi Sistem Manajemen DAFFOOD berhasil ditampilkan.';
            toastMessage.classList.add('is-visible');
            clearTimeout(toastTimer);
            toastTimer = setTimeout(() => toastMessage.classList.remove('is-visible'), 2600);
        });

        // TUGAS BAB 4 - Event mouseenter/mouseleave menahan lalu melanjutkan waktu tampil pesan.
        toastMessage.addEventListener('mouseenter', () => clearTimeout(toastTimer));
        toastMessage.addEventListener('mouseleave', () => {
            toastTimer = setTimeout(() => toastMessage.classList.remove('is-visible'), 2600);
        });
    </script>
    <script src="js/common.js"></script>
</body>
</html>
