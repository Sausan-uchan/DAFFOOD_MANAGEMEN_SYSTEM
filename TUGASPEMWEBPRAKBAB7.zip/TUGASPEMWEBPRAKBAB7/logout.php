<?php
// IMPLEMENTASI TUGAS BAB 5 NOMOR 2: menghapus seluruh data session saat pengguna logout.
session_start();
session_unset();
session_destroy();
header('Location: login.php?logout=success');
exit;
?>
