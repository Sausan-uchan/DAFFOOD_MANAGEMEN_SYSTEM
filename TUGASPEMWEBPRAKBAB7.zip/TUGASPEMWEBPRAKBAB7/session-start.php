<?php
// IMPLEMENTASI TUGAS BAB 5 NOMOR 2: memulai session untuk menyimpan identitas pengguna.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
