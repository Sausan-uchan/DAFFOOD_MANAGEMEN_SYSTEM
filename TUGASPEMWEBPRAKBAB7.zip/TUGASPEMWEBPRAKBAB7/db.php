<?php
// TUGAS BAB 7 - Koneksi database MySQL DAFFOOD menggunakan PDO.
$host = 'localhost';
$dbname = 'db_daffood';
$username = 'root';
$password = ''; // Sesuaikan jika MySQL memiliki password.

try {
    $pdo = new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
        $username,
        $password,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $error) {
    http_response_code(500);
    exit('Koneksi database gagal. Pastikan MySQL aktif dan database db_daffood sudah diimpor.');
}
