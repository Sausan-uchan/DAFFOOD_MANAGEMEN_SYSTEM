# DAFFOOD - Praktikum BAB 7

Project DAFFOOD ini menerapkan proses registrasi/login berbasis database MySQL serta CRUD data menu pada dashboard admin. Fitur BAB 5 tetap dipertahankan.

## Fitur Tugas BAB 7

### 1. Registrasi dan Login
- `register.php` menerima nama, email, dan password, memvalidasi input, memeriksa email duplikat, lalu menyimpan akun ke tabel `tb_user`.
- Password disimpan menggunakan `password_hash()` dan diperiksa dengan `password_verify()` saat login. Password tidak disimpan dalam bentuk teks biasa.
- `login.php` mengambil akun dari database dan membuat PHP Session jika kredensial benar.
- `logout.php` menghapus session.

### 2. CRUD Menu
- Klik menu **Produk & Menu** pada sidebar dashboard untuk membuka `menu.php`.
- Create: isi form Tambah Menu Baru.
- Read: daftar menu ditampilkan dari tabel `tb_menu`.
- Update: klik tombol Edit, ubah data, lalu Simpan Perubahan.
- Delete: klik Hapus dan konfirmasi.
- Semua query menggunakan PDO prepared statement.

## Cara Instalasi dan Menjalankan (XAMPP)
1. Ekstrak folder `TUGASPEMWEBPRAKBAB5` ke `C:\xampp\htdocs\`.
2. Jalankan **Apache** dan **MySQL** dari XAMPP Control Panel.
3. Buka `http://localhost/phpmyadmin`.
4. Pilih menu **Import**, lalu pilih file `db_daffood_bab7.sql` yang ada di folder project. Jalankan import. File ini berisi tabel DAFFOOD awal (`tb_menu`, `tb_pemesanan`, dan lainnya) serta tabel baru `tb_user` untuk BAB 7.
5. Periksa pengaturan koneksi pada `db.php`. Default XAMPP: host `localhost`, database `db_daffood`, username `root`, password kosong. Sesuaikan jika konfigurasi MySQL berbeda.
6. Buka `http://localhost/TUGASPEMWEBPRAKBAB5/index.php`.
7. Klik Daftar/Register, isi nama, email, dan password minimal 6 karakter. Setelah berhasil, pengguna otomatis masuk ke dashboard.
8. Untuk menguji login, klik Keluar, lalu login kembali menggunakan email dan password yang sudah didaftarkan.
9. Pada dashboard, klik **Produk & Menu** di sidebar. Coba tambah, edit, dan hapus salah satu data menu.

## File yang Ditambahkan atau Diubah untuk BAB 7
- `db.php` (baru): koneksi PDO ke database MySQL.
- `db_daffood_bab7.sql` (baru): dump database ditambah tabel `tb_user`.
- `register.php` (diubah): registrasi menyimpan akun ke database.
- `login.php` (diubah): login memverifikasi akun dari database.
- `dashboard.php` (diubah): tautan Produk & Menu menuju halaman CRUD.
- `menu.php` (baru): implementasi Create, Read, Update, Delete tabel `tb_menu`.

## Penanda Komentar Kode
Seluruh logika yang dibuat/diubah untuk ketentuan tugas diberi komentar dengan awalan **`TUGAS BAB 7`**.

## Catatan
- Registrasi harus dilakukan terlebih dahulu untuk membuat akun. Tidak ada akun contoh atau password default.
- Pastikan ekstensi PHP PDO MySQL aktif pada XAMPP.
- CRUD mengelola tabel `tb_menu` pada database MySQL, bukan localStorage browser.
