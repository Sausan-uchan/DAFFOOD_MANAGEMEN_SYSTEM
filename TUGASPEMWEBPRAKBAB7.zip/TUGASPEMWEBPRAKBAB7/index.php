<?php require_once __DIR__ . "/session-start.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TUGAS BAB 4 - Sistem Manajemen DAFFOOD</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="home-page">
    <header class="home-header">
        <a class="home-brand" href="index.php" aria-label="DAFFOOD beranda"><span class="home-brand-mark">D</span>DAFFOOD</a>
        <nav class="home-nav" aria-label="Navigasi utama">
            <a class="home-nav-link" href="#fitur">Fitur sistem</a>
            <a class="home-login" href="login.php">Masuk</a>
            <a class="home-register" href="register.php">Mulai sekarang <span aria-hidden="true">↗</span></a>
        </nav>
    </header>

    <main>
        <section class="home-hero demo-home-hero" id="solusi">
            <div class="home-hero-copy">
                <p class="home-kicker"><span></span> TUGAS BAB 4 • DAFFOOD</p>
                <h1>Sistem Manajemen<br>DAFFOOD<span>.</span></h1>
                <p class="home-subtitle">Operasional restoran<br><strong>lebih mudah dikelola.</strong></p>
                <p class="home-description">Kelola menu, pesanan, laporan penjualan, dan persediaan restoran dalam satu sistem. Interaksi aplikasi didukung DOM, Popup Box, event, Web Storage, serta proses asynchronous berbasis Promise.</p>
                <div class="home-actions">
                    <a href="#fitur" class="home-cta">Jelajahi fitur <span aria-hidden="true">↓</span></a>
                    <a href="dashboard.php" class="home-secondary">Buka sistem</a>
                </div>
                <div class="home-proof"><div class="proof-mark" aria-hidden="true">✓</div><p><strong>Pengelolaan terintegrasi</strong><span>Menu, pesanan, laporan, dan stok restoran.</span></p></div>
            </div>
            <div class="home-hero-visual demo-hero-visual">
                <img src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&amp;fit=crop&amp;w=1300&amp;q=85" alt="Hidangan segar berwarna-warni tersaji di atas meja" fetchpriority="high">
                <div class="visual-caption"><span class="caption-rule"></span><span>DAFFOOD • DEMO INTERAKTIF</span></div>
            </div>
        </section>

        <!-- TUGAS BAB 4 - Fitur Sistem Manajemen DAFFOOD menggunakan DOM, event, dan Web Storage. -->
        <section class="home-benefits demo-directory" id="fitur" aria-label="Fitur Sistem Manajemen DAFFOOD">
            <div class="benefit-intro">
                <span class="benefit-index">FITUR SISTEM DAFFOOD</span>
                <h2>Seluruh kebutuhan operasional restoran dalam satu workspace.</h2>
                <p class="directory-copy">Fitur pengelolaan menu, pesanan, laporan penjualan, dan pemantauan persediaan dibuat interaktif dengan DOM dan event. Data tersimpan di browser.</p>
            </div>
            <div class="demo-card-grid">
                <article class="demo-card">
                    <span class="feature-label dom-label">KATALOG • PESANAN</span>
                    <h3>Kelola menu &amp; pesanan</h3>
                    <p>Tambah, tampilkan, edit, cari, dan hapus menu maupun pesanan restoran.</p>
                    <a href="dashboard.php#menu">Kelola data restoran <span aria-hidden="true">→</span></a>
                </article>
                <article class="demo-card">
                    <span class="feature-label toast-label">PEMBERITAHUAN SISTEM</span>
                    <h3>Informasi aktivitas</h3>
                    <p>Terima pemberitahuan setelah login, pendaftaran, serta perubahan data operasional.</p>
                    <a href="toast.php">Lihat pemberitahuan <span aria-hidden="true">→</span></a>
                </article>
            </div>
        </section>
    </main>
    <footer class="home-footer"><span>DAFFOOD</span><span>Sistem Manajemen Restoran</span><a href="login.php">Masuk ke workspace ↗</a></footer>
    <script src="js/common.js"></script>
</body>
</html>
