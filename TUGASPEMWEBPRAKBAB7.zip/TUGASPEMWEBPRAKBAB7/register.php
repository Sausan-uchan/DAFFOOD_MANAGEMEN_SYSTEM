<?php
require_once __DIR__ . '/session-start.php';
require_once __DIR__ . '/db.php';
$registerError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // TUGAS BAB 7 - Mengambil dan memvalidasi data registrasi sebelum disimpan ke MySQL.
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if ($name === '' || $email === '' || $password === '') {
        $registerError = 'Semua field wajib diisi.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $registerError = 'Format email tidak valid.';
    } elseif (strlen($password) < 6) {
        $registerError = 'Kata sandi minimal 6 karakter.';
    } else {
        // TUGAS BAB 7 - Cek email agar satu email hanya dapat digunakan untuk satu akun.
        $check = $pdo->prepare('SELECT id_user FROM tb_user WHERE email = ? LIMIT 1');
        $check->execute([$email]);
        if ($check->fetch()) {
            $registerError = 'Email sudah terdaftar. Silakan gunakan email lain atau login.';
        } else {
            // TUGAS BAB 7 - Password di-hash, lalu data akun disimpan secara permanen ke tabel tb_user.
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $insert = $pdo->prepare('INSERT INTO tb_user (nama, email, password) VALUES (?, ?, ?)');
            $insert->execute([$name, $email, $hashedPassword]);
            // TUGAS BAB 7 - Simpan ID akun hasil registrasi ke session.
            $newUserId = (int) $pdo->lastInsertId();
            session_regenerate_id(true);
            $_SESSION['user_id'] = $newUserId;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            $_SESSION['logged_in'] = true;
            header('Location: dashboard.php?welcome=register');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - DAFFOOD</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="login-page">
    <main class="login-layout">
        <section class="login-showcase" aria-label="DAFFOOD">
            <img src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&amp;fit=crop&amp;w=1400&amp;q=85" alt="Hidangan segar siap disajikan">
            <div class="login-showcase-overlay"></div>
            <a class="login-brand" href="index.php"><span class="login-brand-mark">D</span>DAFFOOD</a>
            <div class="login-showcase-copy">
                <p class="login-kicker">MULAI BERSAMA DAFFOOD</p>
                <h1>Bangun layanan<br>yang lebih tertata.</h1>
                <p>Satukan pengelolaan menu dan pesanan dalam workspace restoran Anda.</p>
            </div>
            <span class="login-showcase-note">MANAJEMEN RESTORAN TERPADU</span>
        </section>
        <section class="login-content">
            <div class="login-form-wrap register-form-wrap">
                <a class="login-back" href="index.php"><span aria-hidden="true">←</span> Kembali ke beranda</a>
                <p class="login-eyebrow">BUAT WORKSPACE ANDA</p>
                <h2>Daftar akun</h2>
                <p class="login-intro">Isi detail berikut untuk menyiapkan akun administrator DAFFOOD.</p>
                <form class="login-form" id="register-form" action="register.php" method="POST">
                    <label for="register-name">Nama lengkap</label>
                    <input id="register-name" name="name" type="text" class="login-input" placeholder="Nama Anda" autocomplete="name" required>
                    <label for="register-email">Alamat email</label>
                    <input id="register-email" name="email" type="email" class="login-input" placeholder="nama@email.com" autocomplete="email" required>
                    <label for="register-password">Kata sandi</label>
                    <input id="register-password" name="password" type="password" class="login-input" placeholder="Buat kata sandi" autocomplete="new-password" required>
                    <label class="register-consent"><input type="checkbox" required><span>Saya menyetujui syarat penggunaan DAFFOOD.</span></label>
                    <button class="login-submit" type="submit">Buat akun <span aria-hidden="true">→</span></button>
                </form>
                <p class="login-register">Sudah memiliki akun? <a href="login.php">Masuk di sini</a></p>
                <p class="login-footnote"><span aria-hidden="true">●</span> Workspace DAFFOOD terlindungi</p>
            </div>
        </section>
    </main>
    <!-- PENANDA TOAST/SNACKBAR: pesan hasil pengiriman form registrasi. -->
    <div class="toast" id="register-toast" role="status" aria-live="polite"></div>
    <script src="js/common.js"></script>
    <?php if ($registerError !== ''): ?>
        <script>window.addEventListener('DOMContentLoaded', () => { const el = document.getElementById('register-toast'); el.textContent = <?php echo json_encode($registerError); ?>; el.classList.add('visible'); });</script>
    <?php endif; ?>
</body>
</html>