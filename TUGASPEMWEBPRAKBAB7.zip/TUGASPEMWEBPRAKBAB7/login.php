<?php
require_once __DIR__ . '/session-start.php';
require_once __DIR__ . '/db.php';
$loginError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // TUGAS BAB 7 - Mengambil email dan password yang dikirim dari form login.
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    if ($email === '' || $password === '') {
        $loginError = 'Email dan kata sandi wajib diisi.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $loginError = 'Format email tidak valid.';
    } else {
        // TUGAS BAB 7 - Mencari akun berdasarkan email dan memverifikasi password hash dari database.
        $statement = $pdo->prepare('SELECT id_user, nama, email, password FROM tb_user WHERE email = ? LIMIT 1');
        $statement->execute([$email]);
        $account = $statement->fetch();
        if (!$account || !password_verify($password, $account['password'])) {
            $loginError = 'Email atau kata sandi salah. Silakan periksa kembali.';
        } else {
            // TUGAS BAB 7 - Membuat session login setelah autentikasi berhasil.
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int) $account['id_user'];
            $_SESSION['user_name'] = $account['nama'];
            $_SESSION['user_email'] = $account['email'];
            $_SESSION['logged_in'] = true;
            header('Location: dashboard.php?welcome=login');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login - DAFFOOD</title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body class="login-page">
        <main class="login-layout">
            <section class="login-showcase" aria-label="DAFFOOD">
                <img
                    src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&amp;fit=crop&amp;w=1400&amp;q=85"
                    alt="Hidangan segar siap disajikan">
                <div class="login-showcase-overlay"></div>
                <a class="login-brand" href="index.php"><span
                        class="login-brand-mark">D</span>DAFFOOD</a>
                <div class="login-showcase-copy">
                    <p class="login-kicker">RUANG KERJA RESTORAN</p>
                    <h1>Setiap detail<br>lebih terkendali.</h1>
                    <p>Kelola menu dan pesanan dengan alur kerja yang terasa
                        lebih sederhana.</p>
                </div>
                <span class="login-showcase-note">MANAJEMEN RESTORAN
                    TERPADU</span>
            </section>
            <section class="login-content">
                <div class="login-form-wrap">
                    <a class="login-back" href="index.php"><span
                            aria-hidden="true">←</span> Kembali ke beranda</a>
                    <p class="login-eyebrow">SELAMAT DATANG KEMBALI</p>
                    <h2>Masuk ke akun</h2>
                    <p class="login-intro">Gunakan akun administrator untuk
                        melanjutkan ke workspace DAFFOOD.</p>
                    <form class="login-form" id="login-form"
                        action="login.php" method="POST">
                        <label for="login-email">Alamat email</label>
                        <input id="login-email" name="email" type="email"
                            class="login-input" placeholder="nama@email.com"
                            autocomplete="username" required>
                        <label for="login-password">Kata sandi</label>
                        <div class="password-field">
                            <input id="login-password" name="password"
                                type="password" class="login-input"
                                placeholder="Masukkan kata sandi"
                                autocomplete="current-password" required>
                            <button class="password-toggle" type="button"
                                aria-label="Tampilkan kata sandi"
                                aria-pressed="false">Tampilkan</button>
                        </div>
                        <button class="login-submit" type="submit">Masuk ke
                            dashboard <span aria-hidden="true">→</span></button>
                    </form>
                    <p class="login-register">Belum memiliki akun? <a
                            href="register.php">Daftar sekarang</a></p>
                    <p class="login-footnote"><span aria-hidden="true">●</span>
                        Workspace DAFFOOD terlindungi</p>
                </div>
            </section>
        </main>
        <!-- PENANDA TOAST/SNACKBAR: pesan hasil pengiriman form login. -->
        <div class="toast" id="login-toast" role="status"
            aria-live="polite"></div>
        <script src="js/common.js"></script>
        <script>
        const passwordInput = document.getElementById('login-password');
        const passwordToggle = document.querySelector('.password-toggle');
        const loginToast = document.getElementById('login-toast');
        <?php if ($loginError !== ''): ?>
        loginToast.textContent = <?php echo json_encode($loginError); ?>;
        loginToast.classList.add('visible');
        <?php elseif (isset($_GET['logout'])): ?>
        loginToast.textContent = 'Anda berhasil logout.';
        loginToast.classList.add('visible');
        <?php endif; ?>

        passwordToggle.addEventListener('click', () => {
            const isVisible = passwordInput.type === 'text';
            passwordInput.type = isVisible ? 'password' : 'text';
            passwordToggle.textContent = isVisible ? 'Tampilkan' : 'Sembunyikan';
            passwordToggle.setAttribute('aria-label', isVisible ? 'Tampilkan kata sandi' : 'Sembunyikan kata sandi');
            passwordToggle.setAttribute('aria-pressed', String(!isVisible));
        });
    </script>
    </body>
</html>