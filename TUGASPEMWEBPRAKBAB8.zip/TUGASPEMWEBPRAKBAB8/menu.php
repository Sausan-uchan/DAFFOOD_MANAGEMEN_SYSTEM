
<?php
// ======================================================
// 1. SESSION DAN KEAMANAN HALAMAN
// ======================================================
require_once __DIR__ . '/session-start.php';

if (empty($_SESSION['logged_in']) || empty($_SESSION['user_name'])) {
    header('Location: login.php?required=1');
    exit;
}

$userName = $_SESSION['user_name'];
$userInitial = strtoupper(substr($userName, 0, 1));

// ======================================================
// 2. KONEKSI DATABASE
// ======================================================
$host = "localhost";
$username = "root";
$password = "";
$database = "db_daffood";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

// ======================================================
// 3. FUNGSI PEMBERITAHUAN
// ======================================================
$pesan = "";
$jenisPesan = "success";
$editData = null;

function bersihkan($data) {
    return htmlspecialchars((string)$data, ENT_QUOTES, 'UTF-8');
}

// ======================================================
// 4. PROSES TAMBAH DATA MENU
// ======================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {

    $nama = trim($_POST['nama_menu'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $harga = (float)($_POST['harga'] ?? 0);
    $stok = (int)($_POST['stok'] ?? 0);

    if ($nama === '' || $kategori === '' || $harga <= 0 || $stok < 0) {
        $pesan = "Data menu tidak valid. Periksa kembali input.";
        $jenisPesan = "error";
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO tb_menu (nama_menu, kategori, harga, stok)
             VALUES (?, ?, ?, ?)"
        );

        $stmt->bind_param("ssdi", $nama, $kategori, $harga, $stok);

        if ($stmt->execute()) {
            header("Location: menu.php?status=tambah");
            exit;
        } else {
            $pesan = "Gagal menambahkan menu: " . $stmt->error;
            $jenisPesan = "error";
        }

        $stmt->close();
    }
}

// ======================================================
// 5. PROSES UPDATE DATA MENU
// ======================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {

    $id = (int)($_POST['id_menu'] ?? 0);
    $nama = trim($_POST['nama_menu'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $harga = (float)($_POST['harga'] ?? 0);
    $stok = (int)($_POST['stok'] ?? 0);

    if ($id <= 0 || $nama === '' || $kategori === '' || $harga <= 0 || $stok < 0) {
        $pesan = "Data perubahan tidak valid.";
        $jenisPesan = "error";
    } else {
        $stmt = $conn->prepare(
            "UPDATE tb_menu
             SET nama_menu = ?, kategori = ?, harga = ?, stok = ?
             WHERE id_menu = ?"
        );

        $stmt->bind_param("ssdii", $nama, $kategori, $harga, $stok, $id);

        if ($stmt->execute()) {
            header("Location: menu.php?status=update");
            exit;
        } else {
            $pesan = "Gagal memperbarui menu.";
            $jenisPesan = "error";
        }

        $stmt->close();
    }
}

// ======================================================
// 6. PROSES HAPUS DATA MENU
// ======================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus'])) {

    $id = (int)($_POST['id_menu'] ?? 0);

    if ($id > 0) {
        $stmt = $conn->prepare(
            "DELETE FROM tb_menu WHERE id_menu = ?"
        );

        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                header("Location: menu.php?status=hapus");
                exit;
            } else {
                $pesan = "Data menu tidak ditemukan.";
                $jenisPesan = "error";
            }
        } else {
            $pesan = "Menu tidak dapat dihapus. Periksa relasi data pesanan.";
            $jenisPesan = "error";
        }

        $stmt->close();
    }
}

// ======================================================
// 7. AMBIL DATA UNTUK FORM EDIT
// ======================================================
if (isset($_GET['edit'])) {

    $id = (int)$_GET['edit'];

    if ($id > 0) {
        $stmt = $conn->prepare(
            "SELECT * FROM tb_menu WHERE id_menu = ?"
        );

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $resultEdit = $stmt->get_result();
        $editData = $resultEdit->fetch_assoc();

        $stmt->close();
    }
}

// ======================================================
// 8. AMBIL SELURUH DATA MENU
// ======================================================
$dataMenu = $conn->query(
    "SELECT * FROM tb_menu ORDER BY id_menu DESC"
);

if (!$dataMenu) {
    die("Gagal mengambil data menu: " . $conn->error);
}

$totalMenu = $dataMenu->num_rows;

// ======================================================
// 9. PESAN BERDASARKAN HASIL OPERASI
// ======================================================
if (isset($_GET['status'])) {
    switch ($_GET['status']) {
        case 'tambah':
            $pesan = "Menu berhasil ditambahkan!";
            break;
        case 'update':
            $pesan = "Menu berhasil diperbarui!";
            break;
        case 'hapus':
            $pesan = "Menu berhasil dihapus!";
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="theme-color" content="#f3f7fc">

    <title>Pengelolaan Menu | DAFFOOD</title>

    <!-- CSS UTAMA DASHBOARD -->
    <link rel="stylesheet" href="css/style.css">

    <!-- CSS TAMBAHAN HALAMAN MENU -->
    <style>
        .menu-crud-page {
            padding-bottom: 30px;
        }

        .menu-form-card {
            padding: 24px;
            margin-bottom: 23px;
            border: 1px solid var(--dash-line);
            border-radius: 9px;
            background: #fff;
            box-shadow: 0 3px 12px rgba(29, 62, 101, .025);
        }

        .menu-form-card h2 {
            margin: 0 0 20px;
            color: #1b3453;
            font-size: 17px;
        }

        .menu-form-grid {
            display: grid;
            grid-template-columns: 2fr 1.2fr 1fr 1fr auto;
            align-items: end;
            gap: 12px;
        }

        .menu-field {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .menu-field label {
            color: #405773;
            font-size: 11px;
            font-weight: 700;
        }

        .menu-field input,
        .menu-field select {
            width: 100%;
            height: 39px;
            padding: 0 11px;
            border: 1px solid #dce5f0;
            border-radius: 6px;
            outline: none;
            color: #263d59;
            background: #fff;
            font: inherit;
            font-size: 12px;
        }

        .menu-field input:focus,
        .menu-field select:focus {
            border-color: #438cdd;
            box-shadow: 0 0 0 3px rgba(39, 125, 218, .09);
        }

        .menu-submit {
            min-height: 39px;
            padding: 0 16px;
            border: none;
            border-radius: 6px;
            color: white;
            background: #1769d2;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
            white-space: nowrap;
        }

        .menu-submit:hover {
            background: #1056b3;
        }

        .menu-cancel {
            display: inline-flex;
            min-height: 39px;
            align-items: center;
            justify-content: center;
            padding: 0 14px;
            border-radius: 6px;
            color: #405773;
            background: #edf2f8;
            font-size: 12px;
            text-decoration: none;
        }

        .menu-alert {
            margin-bottom: 18px;
            padding: 13px 16px;
            border-radius: 7px;
            font-size: 12px;
        }

        .menu-alert.success {
            color: #146c43;
            background: #dff5e9;
        }

        .menu-alert.error {
            color: #a32929;
            background: #ffe5e5;
        }

        .menu-table-card {
            padding: 21px 22px 15px;
            border: 1px solid var(--dash-line);
            border-radius: 9px;
            background: #fff;
            box-shadow: 0 3px 12px rgba(29, 62, 101, .025);
        }

        .menu-table-heading {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }

        .menu-table-heading h2 {
            margin: 0;
            color: #1b3453;
            font-size: 17px;
        }

        .menu-count {
            color: #74849a;
            font-size: 11px;
        }

        .menu-table-card .table-wrap {
            margin-top: 16px;
        }

        .menu-action {
            display: flex;
            align-items: center;
            gap: 7px;
        }

        .menu-edit,
        .menu-delete {
            min-height: 34px;
            padding: 0 13px;
            border: none;
            border-radius: 7px;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .menu-edit {
            color: #1559a7;
            background: #eaf2fc;
        }

        .menu-delete {
            color: #fff;
            background: #e84141;
        }

        .menu-edit:hover {
            background: #d7e8fc;
        }

        .menu-delete:hover {
            background: #ca3030;
        }

        .menu-status {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 5px;
            color: #13714b;
            background: #e2f6eb;
            font-size: 10px;
            font-weight: 700;
        }

        .menu-status.empty {
            color: #b12d2d;
            background: #ffe6e6;
        }

        .menu-empty {
            padding: 30px !important;
            text-align: center;
            color: #8392a5 !important;
        }

        .dashboard-page[data-mode="dark"] .menu-form-card,
        .dashboard-page[data-mode="dark"] .menu-table-card {
            background: var(--theme-surface, #182b40);
            border-color: var(--dash-line);
        }

        .dashboard-page[data-mode="dark"] .menu-form-card h2,
        .dashboard-page[data-mode="dark"] .menu-table-heading h2 {
            color: var(--theme-ink, #e8f0fa);
        }

        .dashboard-page[data-mode="dark"] .menu-field input,
        .dashboard-page[data-mode="dark"] .menu-field select {
            color: var(--theme-ink, #e8f0fa);
            background: #20374f;
            border-color: #40536b;
        }

        @media (max-width: 1100px) {
            .menu-form-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .menu-submit,
            .menu-cancel {
                width: 100%;
            }
        }

        @media (max-width: 700px) {
            .dashboard-page .sidebar {
                position: relative;
                width: 100%;
                min-height: auto;
            }

            .dashboard-page .main-content {
                margin-left: 0;
                padding: 0 16px 24px;
            }

            .menu-form-grid {
                grid-template-columns: 1fr;
            }

            .menu-table-card,
            .menu-form-card {
                padding: 16px;
            }

            .page-intro {
                align-items: flex-start;
                flex-direction: column;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
                gap: 12px;
                padding: 15px 0;
            }

            .dashboard-tools {
                flex-wrap: wrap;
                justify-content: flex-start;
            }
        }
    </style>
</head>

<body class="dashboard-page">

<div class="dashboard-layout">

    <!-- =================================================
         10. SIDEBAR DASHBOARD
    ================================================== -->
    <aside class="sidebar">

        <a class="sidebar-brand" href="dashboard.php">
            <span class="brand-mark">D</span>
            <span>
                DAFFOOD
                <small>FOOD MANAGEMENT</small>
            </span>
        </a>

        <p class="sidebar-label">MENU UTAMA</p>

        <nav class="sidebar-menu">

            <a class="nav-link" href="dashboard.php#overview">
                <span class="nav-icon">⌂</span>
                Ringkasan
            </a>

            <a class="nav-link active" href="menu.php">
                <span class="nav-icon">▦</span>
                Produk & Menu
            </a>

            <a class="nav-link" href="pesanan.php">
                <span class="nav-icon">▤</span>
                Manajemen Pesanan
            </a>

            <a class="nav-link" href="dashboard.php#reports">
                <span class="nav-icon">▥</span>
                Laporan Penjualan
            </a>

            <a class="nav-link" href="dashboard.php#inventory">
                <span class="nav-icon">◉</span>
                Pemantauan Stok
            </a>

        </nav>

        <div class="sidebar-bottom">

            <div class="profile-chip">

                <span class="profile-avatar">
                    <?= bersihkan($userInitial); ?>
                </span>

                <span>
                    <strong><?= bersihkan($userName); ?></strong>
                    <small>Admin DAFFOOD</small>
                </span>

            </div>

            <a class="logout-link" href="logout.php"
               onclick="return confirm('Apakah Anda yakin ingin keluar?')">

                Keluar
                <span>↗</span>

            </a>

        </div>

    </aside>

    <!-- =================================================
         11. KONTEN UTAMA DASHBOARD
    ================================================== -->
    <main class="main-content">

        <!-- HEADER -->
        <header class="topbar">

            <div class="breadcrumb">
                Workspace
                <span>/</span>
                <span>Produk & Menu</span>
            </div>

            <div class="dashboard-tools">

                <div class="topbar-date">
                    <span class="status-dot"></span>
                    <span id="live-date"></span>
                    <time id="live-clock"></time>
                </div>

                <button class="theme-toggle"
                        id="theme-toggle"
                        type="button"
                        aria-pressed="false">
                    🌙 Gelap
                </button>

                <label class="theme-picker">
                    Warna
                    <select id="color-theme">
                        <option value="blue">Biru</option>
                        <option value="green">Hijau</option>
                        <option value="cream">Cream</option>
                        <option value="slate">Abu-abu tua</option>
                        <option value="purple">Ungu</option>
                    </select>
                </label>

            </div>

        </header>

        <!-- JUDUL HALAMAN -->
        <section class="menu-crud-page">

            <div class="page-intro">

                <div>

                    <p class="eyebrow">KATALOG RESTORAN</p>

                    <h1>Pengelolaan Produk & Menu</h1>

                    <p class="intro-copy">
                        Halo, <?= bersihkan($userName); ?>.
                        Kelola data menu DAFFOOD melalui database.
                    </p>

                </div>

                <a href="dashboard.php#overview" class="primary-button">
                    ← Dashboard
                </a>

            </div>

            <!-- NOTIFIKASI -->
            <?php if ($pesan !== ''): ?>

                <div class="menu-alert <?= bersihkan($jenisPesan); ?>">
                    <?= bersihkan($pesan); ?>
                </div>

            <?php endif; ?>

            <!-- =================================================
                 12. FORM TAMBAH DAN EDIT MENU
            ================================================== -->

            <section class="menu-form-card">

                <h2>
                    <?= $editData ? 'Edit Data Menu' : 'Tambah Menu Baru'; ?>
                </h2>

                <form action="menu.php" method="POST">

                    <?php if ($editData): ?>

                        <input type="hidden"
                               name="id_menu"
                               value="<?= (int)$editData['id_menu']; ?>">

                    <?php endif; ?>

                    <div class="menu-form-grid">

                        <div class="menu-field">

                            <label>Nama Menu</label>

                            <input
                                type="text"
                                name="nama_menu"
                                placeholder="Contoh: Nasi Goreng"
                                maxlength="100"
                                value="<?= bersihkan($editData['nama_menu'] ?? ''); ?>"
                                required>

                        </div>

                        <div class="menu-field">

                            <label>Kategori</label>

                            <select name="kategori" required>

                                <option value="">Pilih kategori</option>

                                <option value="Makanan"
                                    <?= ($editData['kategori'] ?? '') === 'Makanan' ? 'selected' : ''; ?>>
                                    Makanan
                                </option>

                                <option value="Minuman"
                                    <?= ($editData['kategori'] ?? '') === 'Minuman' ? 'selected' : ''; ?>>
                                    Minuman
                                </option>

                            </select>

                        </div>

                        <div class="menu-field">

                            <label>Harga (Rp)</label>

                            <input
                                type="number"
                                name="harga"
                                placeholder="25000"
                                min="1"
                                step="1"
                                value="<?= bersihkan($editData['harga'] ?? ''); ?>"
                                required>

                        </div>

                        <div class="menu-field">

                            <label>Stok</label>

                            <input
                                type="number"
                                name="stok"
                                placeholder="20"
                                min="0"
                                step="1"
                                value="<?= bersihkan($editData['stok'] ?? ''); ?>"
                                required>

                        </div>

                        <div class="menu-field">

                            <label>&nbsp;</label>

                            <?php if ($editData): ?>

                                <button type="submit"
                                        name="update"
                                        class="menu-submit">
                                    ✓ Simpan Perubahan
                                </button>

                            <?php else: ?>

                                <button type="submit"
                                        name="tambah"
                                        class="menu-submit">
                                    + Tambah Menu
                                </button>

                            <?php endif; ?>

                        </div>

                        <?php if ($editData): ?>

                            <a href="menu.php" class="menu-cancel">
                                Batal Edit
                            </a>

                        <?php endif; ?>

                    </div>

                </form>

            </section>

            <!-- =================================================
                 13. TABEL DAFTAR MENU
            ================================================== -->

            <section class="menu-table-card">

                <div class="menu-table-heading">

                    <h2>Daftar Menu</h2>

                    <span class="menu-count">
                        <?= $totalMenu; ?> data menu
                    </span>

                </div>

                <div class="table-toolbar">

                    <label class="search-box">

                        <span>⌕</span>

                        <input
                            type="search"
                            id="search-menu"
                            placeholder="Cari nama menu atau kategori...">

                    </label>

                </div>

                <div class="table-wrap">

                    <table>

                        <thead>

                            <tr>
                                <th>ID</th>
                                <th>NAMA MENU</th>
                                <th>KATEGORI</th>
                                <th>HARGA</th>
                                <th>STOK</th>
                                <th>STATUS</th>
                                <th>AKSI</th>
                            </tr>

                        </thead>

                        <tbody id="menu-table-body">

                            <?php if ($totalMenu > 0): ?>

                                <?php while ($row = $dataMenu->fetch_assoc()): ?>

                                    <tr>

                                        <td>
                                            <?= (int)$row['id_menu']; ?>
                                        </td>

                                        <td>
                                            <strong>
                                                <?= bersihkan($row['nama_menu']); ?>
                                            </strong>
                                        </td>

                                        <td>
                                            <?= bersihkan($row['kategori']); ?>
                                        </td>

                                        <td>
                                            Rp<?= number_format((float)$row['harga'], 0, ',', '.'); ?>
                                        </td>

                                        <td>
                                            <?= (int)$row['stok']; ?>
                                        </td>

                                        <td>

                                            <?php if ((int)$row['stok'] > 0): ?>

                                                <span class="menu-status">
                                                    Tersedia
                                                </span>

                                            <?php else: ?>

                                                <span class="menu-status empty">
                                                    Habis
                                                </span>

                                            <?php endif; ?>

                                        </td>

                                        <td>

                                            <div class="menu-action">

                                                <!-- TOMBOL EDIT -->
                                                <a
                                                    href="menu.php?edit=<?= (int)$row['id_menu']; ?>"
                                                    class="menu-edit">
                                                    Edit
                                                </a>

                                                <!-- TOMBOL HAPUS -->
                                                <form
                                                    action="menu.php"
                                                    method="POST"
                                                    onsubmit="return confirm('Yakin ingin menghapus menu ini?')">

                                                    <input
                                                        type="hidden"
                                                        name="id_menu"
                                                        value="<?= (int)$row['id_menu']; ?>">

                                                    <button
                                                        type="submit"
                                                        name="hapus"
                                                        class="menu-delete">
                                                        Hapus
                                                    </button>

                                                </form>

                                            </div>

                                        </td>

                                    </tr>

                                <?php endwhile; ?>

                            <?php else: ?>

                                <tr>
                                    <td colspan="7" class="menu-empty">
                                        Belum ada data menu.
                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </section>

        </section>

        <!-- FOOTER -->
        <footer class="dashboard-footer">
            DAFFOOD <span>•</span> Sistem Manajemen Restoran
        </footer>

    </main>

</div>

<!-- =================================================
     14. JAVASCRIPT DASHBOARD
================================================== -->

<script src="js/common.js"></script>

<script>

// ==================================================
// JAM DAN TANGGAL
// ==================================================

function updateClock() {

    const now = new Date();

    document.getElementById('live-date').textContent =
        now.toLocaleDateString('id-ID', {
            weekday: 'short',
            day: 'numeric',
            month: 'short',
            year: '2-digit'
        });

    document.getElementById('live-clock').textContent =
        now.toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });

}

updateClock();

setInterval(updateClock, 1000);

// ==================================================
// PENCARIAN DATA MENU
// ==================================================

const searchMenu = document.getElementById('search-menu');

searchMenu.addEventListener('input', function () {

    const keyword = this.value.toLowerCase();

    const rows = document.querySelectorAll(
        '#menu-table-body tr'
    );

    rows.forEach(function(row) {

        const text = row.textContent.toLowerCase();

        row.style.display =
            text.includes(keyword) ? '' : 'none';

    });

});

// ==================================================
// TOMBOL TEMA GELAP
// ==================================================

const themeToggle = document.getElementById('theme-toggle');
const colorTheme = document.getElementById('color-theme');

function applyThemeSettings() {

    const mode = localStorage.getItem('daffood-theme-mode') || 'light';

    const color = localStorage.getItem('daffood-color-theme') || 'blue';

    document.body.dataset.mode = mode;

    document.body.dataset.colorTheme = color;

    themeToggle.textContent =
        mode === 'dark' ? '☀️ Terang' : '🌙 Gelap';

    themeToggle.setAttribute(
        'aria-pressed',
        String(mode === 'dark')
    );

    colorTheme.value = color;

}

applyThemeSettings();

themeToggle.addEventListener('click', function() {

    const currentMode =
        document.body.dataset.mode || 'light';

    const newMode =
        currentMode === 'dark' ? 'light' : 'dark';

    localStorage.setItem('daffood-theme-mode', newMode);

    applyThemeSettings();

});

// ==================================================
// PILIHAN WARNA DASHBOARD
// ==================================================

colorTheme.addEventListener('change', function() {

    localStorage.setItem(
        'daffood-color-theme',
        this.value
    );

    applyThemeSettings();

});

</script>

</body>
</html>

<?php
// ======================================================
// 15. TUTUP KONEKSI DATABASE
// ======================================================
$conn->close();
?>