<?php
// TUGAS BAB 8 - Cetak data pemesanan (tb_pemesanan) ke file PDF.
require_once __DIR__ . '/session-start.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/lib/pesanan.php';
require_once __DIR__ . '/lib/SimplePdf.php';

// Hanya admin yang sudah login yang boleh mencetak.
if (empty($_SESSION['logged_in']) || empty($_SESSION['user_name'])) {
    header('Location: login.php?required=1');
    exit;
}

$q = trim($_GET['q'] ?? '');
$status = trim($_GET['status'] ?? '');
$rows = ambilPesanan($pdo, $q, $status);
$admin = $_SESSION['user_name'];

$bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
$tglCetak = date('j') . ' ' . $bulan[(int) date('n') - 1] . ' ' . date('Y, H:i');

// Definisi kolom tabel: [judul, lebar, rata]
$cols = [['No', 32, 'C'], ['ID', 40, 'C'], ['Pelanggan', 150, 'L'], ['Tanggal pesan', 110, 'L'], ['Status', 70, 'C'], ['Total harga', 93, 'R']];
$left = 51;
$tableW = array_sum(array_column($cols, 1));
$rowH = 22;
$bottomLimit = SimplePdf::H - 60;

$pdf = new SimplePdf();

function headerHalaman(SimplePdf $pdf, array $cols, float $left, float $tableW, string $tglCetak, string $admin, string $q, string $status, bool $first): float
{
    $pdf->addPage();
    $pdf->rect(0, 0, SimplePdf::W, 6, '#3b2bd6');
    $y = 48;
    if ($first) {
        $pdf->setFont(true, 20);
        $pdf->text($left, $y, 'DAFFOOD', '#3b2bd6');
        $pdf->setFont(false, 9);
        $pdf->text($left, $y + 15, 'Sistem Manajemen Restoran', '#657890');
        $pdf->setFont(true, 14);
        $pdf->text($left, $y + 50, 'Laporan Data Pemesanan', '#1b3453');
        $pdf->setFont(false, 9);
        $pdf->text($left, $y + 68, 'Dicetak oleh: ' . $admin, '#405773');
        $pdf->text($left, $y + 81, 'Tanggal cetak: ' . $tglCetak, '#405773');
        $filter = 'Filter: ' . ($status !== '' ? "status $status" : 'semua status') . ($q !== '' ? ", kata kunci \"$q\"" : '');
        $pdf->text($left, $y + 94, $pdf->fit($filter, $tableW), '#405773');
        $y += 115;
    } else {
        $pdf->setFont(true, 10);
        $pdf->text($left, $y, 'DAFFOOD - Laporan Data Pemesanan (lanjutan)', '#657890');
        $y += 22;
    }
    // Baris judul kolom
    $pdf->rect($left, $y, $tableW, 24, '#3b2bd6');
    $pdf->setFont(true, 9);
    $x = $left;
    foreach ($cols as [$judul, $w, $align]) {
        $pdf->text($x + 6, $y + 16, $judul, '#ffffff', $align, $w - 12);
        $x += $w;
    }
    return $y + 24;
}

$y = headerHalaman($pdf, $cols, $left, $tableW, $tglCetak, $admin, $q, $status, true);
$no = 0;
$totalNilai = 0;
foreach ($rows as $r) {
    if ($y + $rowH > $bottomLimit) {
        $y = headerHalaman($pdf, $cols, $left, $tableW, $tglCetak, $admin, $q, $status, false);
    }
    $no++;
    if ($r['status_pesanan'] !== 'Batal') $totalNilai += (float) $r['total_harga'];
    if ($no % 2 === 0) $pdf->rect($left, $y, $tableW, $rowH, '#f3f7fc');
    $tgl = date('d/m/Y H:i', strtotime((string) $r['tanggal_pesan']));
    $cells = [(string) $no, (string) $r['id_pemesanan'], $r['nama_pelanggan'], $tgl, $r['status_pesanan'], rupiahFormat($r['total_harga'])];
    $pdf->setFont(false, 9);
    $x = $left;
    foreach ($cols as $i => [$judul, $w, $align]) {
        $teks = $pdf->fit($cells[$i], $w - 12);
        $pdf->text($x + 6, $y + 15, $teks, '#263d59', $align, $w - 12);
        $x += $w;
    }
    $pdf->line($left, $y + $rowH, $left + $tableW, $y + $rowH, '#dce5f0');
    $y += $rowH;
}

if ($no === 0) {
    $pdf->setFont(false, 10);
    $pdf->text($left, $y + 20, 'Tidak ada data pemesanan untuk filter ini.', '#8392a5');
    $y += 30;
}

// Ringkasan di akhir tabel
if ($y + 60 > $bottomLimit) {
    $y = headerHalaman($pdf, $cols, $left, $tableW, $tglCetak, $admin, $q, $status, false) + 4;
}
$y += 14;
$pdf->setFont(true, 10);
$pdf->text($left, $y, 'Jumlah pesanan: ' . $no, '#1b3453');
$pdf->text($left, $y + 16, 'Total nilai (tidak termasuk status Batal): ' . rupiahFormat($totalNilai), '#1b3453');

// Footer + nomor halaman pada setiap halaman.
$total = $pdf->pageCount();
for ($h = 1; $h <= $total; $h++) {
    $pdf->setPage($h);
    $pdf->line($left, SimplePdf::H - 42, $left + $tableW, SimplePdf::H - 42, '#dce5f0');
    $pdf->setFont(false, 8);
    $pdf->text($left, SimplePdf::H - 28, 'DAFFOOD - Sistem Manajemen Restoran', '#8392a5');
    $pdf->text($left, SimplePdf::H - 28, "Halaman $h dari $total", '#8392a5', 'R', $tableW);
}
$out = $pdf->output();

header('Content-Type: application/pdf');
$nama = 'laporan-pemesanan-daffood-' . date('Ymd-His') . '.pdf';
$disposisi = isset($_GET['download']) ? 'attachment' : 'inline';
header("Content-Disposition: $disposisi; filename=\"$nama\"");
header('Content-Length: ' . strlen($out));
echo $out;
