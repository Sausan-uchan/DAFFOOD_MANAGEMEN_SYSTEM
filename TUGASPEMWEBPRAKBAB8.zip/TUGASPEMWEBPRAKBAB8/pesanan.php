<?php
// ======================================================
// TUGAS BAB 8 NOMOR 1 - CRUD data Pemesanan (tabel tb_pemesanan)
// Tabel ini berbeda dari CRUD BAB 7 yang mengelola tb_menu.
// ======================================================
require_once __DIR__ . '/session-start.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/lib/pesanan.php';

// Halaman hanya untuk admin yang sudah login.
if (empty($_SESSION['logged_in']) || empty($_SESSION['user_name'])) {
    header('Location: login.php?required=1');
    exit;
}

$userName = $_SESSION['user_name'];
$userInitial = strtoupper(substr($userName, 0, 1));

function e($data): string
{
    return htmlspecialchars((string) $data, ENT_QUOTES, 'UTF-8');
}

// Token CSRF sederhana agar form tidak bisa dikirim dari situs lain.
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

$pesan = '';
$jenisPesan = 'success';
$editData = null;

// Validasi input form pemesanan. Mengembalikan [data, errorMessage].
function validasiPesanan(array $in): array
{
    $nama = trim($in['nama_pelanggan'] ?? '');
    $status = $in['status_pesanan'] ?? '';
    $total = $in['total_harga'] ?? '';
    $tanggalRaw = trim($in['tanggal_pesan'] ?? '');

    if ($nama === '' || mb_strlen($nama) > 100) {
        return [null, 'Nama pelanggan wajib diisi (maksimal 100 karakter).'];
    }
    if (!in_array($status, STATUS_PESANAN, true)) {
        return [null, 'Status pesanan tidak valid.'];
    }
    if (!is_numeric($total) || (float) $total < 0 || (float) $total > 99999999.99) {
        return [null, 'Total harga harus berupa angka 0 sampai 99.999.999.'];
    }
    $tanggal = DateTime::createFromFormat('Y-m-d\TH:i', $tanggalRaw);
    if (!$tanggal || $tanggal->format('Y-m-d\TH:i') !== $tanggalRaw) {
        return [null, 'Tanggal pesan tidak valid.'];
    }
    return [[
        'nama' => $nama,
        'status' => $status,
        'total' => (float) $total,
        'tanggal' => $tanggal->format('Y-m-d H:i:s'),
    ], null];
}

// ======================================================
// CREATE / UPDATE / DELETE (metode POST + prepared statement)
// ======================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, $_POST['csrf'] ?? '')) {
        $pesan = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
        $jenisPesan = 'error';
    } elseif (isset($_POST['tambah'])) {
        // CREATE
        [$d, $err] = validasiPesanan($_POST);
        if ($err) {
            $pesan = $err;
            $jenisPesan = 'error';
        } else {
            $stmt = $pdo->prepare('INSERT INTO tb_pemesanan (nama_pelanggan, tanggal_pesan, total_harga, status_pesanan) VALUES (?, ?, ?, ?)');
            $stmt->execute([$d['nama'], $d['tanggal'], $d['total'], $d['status']]);
            header('Location: pesanan.php?status_aksi=tambah');
            exit;
        }
    } elseif (isset($_POST['update'])) {
        // UPDATE
        $id = (int) ($_POST['id_pemesanan'] ?? 0);
        [$d, $err] = validasiPesanan($_POST);
        if ($id <= 0 || $err) {
            $pesan = $err ?: 'Data perubahan tidak valid.';
            $jenisPesan = 'error';
            $editData = ['id_pemesanan' => $id, 'nama_pelanggan' => $_POST['nama_pelanggan'] ?? '', 'tanggal_pesan' => str_replace('T', ' ', $_POST['tanggal_pesan'] ?? ''), 'total_harga' => $_POST['total_harga'] ?? '', 'status_pesanan' => $_POST['status_pesanan'] ?? 'Pending'];
        } else {
            $stmt = $pdo->prepare('UPDATE tb_pemesanan SET nama_pelanggan = ?, tanggal_pesan = ?, total_harga = ?, status_pesanan = ? WHERE id_pemesanan = ?');
            $stmt->execute([$d['nama'], $d['tanggal'], $d['total'], $d['status'], $id]);
            header('Location: pesanan.php?status_aksi=update');
            exit;
        }
    } elseif (isset($_POST['hapus'])) {
        // DELETE (rincian pesanan & transaksi terkait ikut terhapus lewat ON DELETE CASCADE)
        $id = (int) ($_POST['id_pemesanan'] ?? 0);
        $stmt = $pdo->prepare('DELETE FROM tb_pemesanan WHERE id_pemesanan = ?');
        $stmt->execute([$id]);
        if ($stmt->rowCount() > 0) {
            header('Location: pesanan.php?status_aksi=hapus');
            exit;
        }
        $pesan = 'Data pesanan tidak ditemukan.';
        $jenisPesan = 'error';
    }
}

// ======================================================
// READ - data untuk form edit dan tabel daftar
// ======================================================
if ($editData === null && isset($_GET['edit'])) {
    $id = (int) $_GET['edit'];
    if ($id > 0) {
        $stmt = $pdo->prepare('SELECT * FROM tb_pemesanan WHERE id_pemesanan = ?');
        $stmt->execute([$id]);
        $editData = $stmt->fetch() ?: null;
    }
}

$q = trim($_GET['q'] ?? '');
$filterStatus = trim($_GET['status'] ?? '');
$dataPesanan = ambilPesanan($pdo, $q, $filterStatus);
$totalPesanan = count($dataPesanan);
$totalSemua = (int) $pdo->query('SELECT COUNT(*) FROM tb_pemesanan')->fetchColumn();

if (isset($_GET['status_aksi']) && $pesan === '') {
    $pesan = ['tambah' => 'Pesanan berhasil ditambahkan!', 'update' => 'Pesanan berhasil diperbarui!', 'hapus' => 'Pesanan berhasil dihapus!'][$_GET['status_aksi']] ?? '';
}

// Query string filter agar tombol cetak PDF mengikuti filter yang sedang aktif.
$filterQuery = http_build_query(array_filter(['q' => $q, 'status' => $filterStatus], fn($v) => $v !== ''));

$tanggalForm = $editData ? date('Y-m-d\TH:i', strtotime((string) $editData['tanggal_pesan'])) : date('Y-m-d\TH:i');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#f3f7fc">
    <title>Manajemen Pesanan | DAFFOOD</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/crud.css">
</head>
<body class="dashboard-page">
<div class="dashboard-layout">

    <aside class="sidebar">
        <a class="sidebar-brand" href="dashboard.php">
            <span class="brand-mark">D</span>
            <span>DAFFOOD<small>FOOD MANAGEMENT</small></span>
        </a>
        <p class="sidebar-label">MENU UTAMA</p>
        <nav class="sidebar-menu">
            <a class="nav-link" href="dashboard.php#overview"><span class="nav-icon">⌂</span>Ringkasan</a>
            <a class="nav-link" href="menu.php"><span class="nav-icon">▦</span>Produk & Menu</a>
            <a class="nav-link active" href="pesanan.php"><span class="nav-icon">▤</span>Manajemen Pesanan</a>
            <a class="nav-link" href="dashboard.php#reports"><span class="nav-icon">▥</span>Laporan Penjualan</a>
            <a class="nav-link" href="dashboard.php#inventory"><span class="nav-icon">◉</span>Pemantauan Stok</a>
        </nav>
        <div class="sidebar-bottom">
            <div class="profile-chip">
                <span class="profile-avatar"><?= e($userInitial); ?></span>
                <span><strong><?= e($userName); ?></strong><small>Admin DAFFOOD</small></span>
            </div>
            <a class="logout-link" href="logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?')">Keluar <span>↗</span></a>
        </div>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div class="breadcrumb">Workspace <span>/</span> <span>Manajemen Pesanan</span></div>
            <div class="dashboard-tools">
                <div class="topbar-date"><span class="status-dot"></span><span id="live-date"></span><time id="live-clock"></time></div>
                <button class="theme-toggle" id="theme-toggle" type="button" aria-pressed="false">🌙 Gelap</button>
                <label class="theme-picker">Warna
                    <select id="color-theme">
                        <option value="blue">Biru</option>
                        <option value="green">Hijau</option>
                        <option value="cream">Cream</option>
                        <option value="slate">Abu-abu tua</option>
                        <option value="purple">Ungu</option>
                    </select>
                </label>
            </div>
        </header>

        <section class="menu-crud-page">
            <div class="page-intro">
                <div>
                    <p class="eyebrow">OPERASIONAL PESANAN</p>
                    <h1>Manajemen Pesanan</h1>
                    <p class="intro-copy">Halo, <?= e($userName); ?>. Kelola data pemesanan pelanggan DAFFOOD melalui database.</p>
                </div>
                <a href="dashboard.php#overview" class="primary-button">← Dashboard</a>
            </div>

            <?php if ($pesan !== ''): ?>
                <div class="menu-alert <?= e($jenisPesan); ?>"><?= e($pesan); ?></div>
            <?php endif; ?>

            <!-- FORM CREATE / UPDATE -->
            <section class="menu-form-card">
                <h2><?= $editData ? 'Edit Data Pesanan #' . (int) $editData['id_pemesanan'] : 'Tambah Pesanan Baru'; ?></h2>
                <form action="pesanan.php" method="POST">
                    <input type="hidden" name="csrf" value="<?= e($csrf); ?>">
                    <?php if ($editData): ?>
                        <input type="hidden" name="id_pemesanan" value="<?= (int) $editData['id_pemesanan']; ?>">
                    <?php endif; ?>
                    <div class="order-form-grid">
                        <div class="menu-field">
                            <label for="f-nama">Nama Pelanggan</label>
                            <input id="f-nama" type="text" name="nama_pelanggan" placeholder="Contoh: Sausan" maxlength="100" value="<?= e($editData['nama_pelanggan'] ?? ''); ?>" required>
                        </div>
                        <div class="menu-field">
                            <label for="f-tgl">Tanggal Pesan</label>
                            <input id="f-tgl" type="datetime-local" name="tanggal_pesan" value="<?= e($tanggalForm); ?>" required>
                        </div>
                        <div class="menu-field">
                            <label for="f-total">Total Harga (Rp)</label>
                            <input id="f-total" type="number" name="total_harga" placeholder="30000" min="0" step="1" value="<?= e(isset($editData['total_harga']) ? (int) $editData['total_harga'] : ''); ?>" required>
                        </div>
                        <div class="menu-field">
                            <label for="f-status">Status</label>
                            <select id="f-status" name="status_pesanan" required>
                                <?php foreach (STATUS_PESANAN as $s): ?>
                                    <option value="<?= e($s); ?>" <?= ($editData['status_pesanan'] ?? 'Pending') === $s ? 'selected' : ''; ?>><?= e($s); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="menu-field">
                            <label>&nbsp;</label>
                            <?php if ($editData): ?>
                                <button type="submit" name="update" class="menu-submit">✓ Simpan Perubahan</button>
                            <?php else: ?>
                                <button type="submit" name="tambah" class="menu-submit">+ Tambah Pesanan</button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($editData): ?>
                        <p style="margin:12px 0 0"><a href="pesanan.php" class="menu-cancel">Batal Edit</a></p>
                    <?php endif; ?>
                </form>
            </section>

            <!-- TABEL READ + FILTER + CETAK PDF -->
            <section class="menu-table-card">
                <div class="menu-table-heading">
                    <h2>Daftar Pesanan</h2>
                    <span class="menu-count"><?= $totalPesanan; ?> dari <?= $totalSemua; ?> data pesanan</span>
                </div>

                <form class="order-filter" action="pesanan.php" method="GET">
                    <label class="search-box"><span>⌕</span>
                        <input type="search" name="q" value="<?= e($q); ?>" placeholder="Cari nama pelanggan atau ID pesanan..." aria-label="Cari pesanan">
                    </label>
                    <select name="status" aria-label="Filter status">
                        <option value="">Semua status</option>
                        <?php foreach (STATUS_PESANAN as $s): ?>
                            <option value="<?= e($s); ?>" <?= $filterStatus === $s ? 'selected' : ''; ?>><?= e($s); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="order-btn">Terapkan</button>
                    <?php if ($q !== '' || $filterStatus !== ''): ?>
                        <a href="pesanan.php" class="order-btn">Reset</a>
                    <?php endif; ?>
                    <!-- TUGAS BAB 8 NOMOR 3: tombol cetak data pesanan ke PDF (mengikuti filter yang aktif) -->
                    <a class="order-btn pdf" href="cetak_pesanan.php<?= $filterQuery ? '?' . e($filterQuery) : ''; ?>" target="_blank" rel="noopener">⎙ Cetak PDF</a>
                    <a class="order-btn" href="cetak_pesanan.php?<?= e($filterQuery ? $filterQuery . '&' : ''); ?>download=1">↓ Unduh PDF</a>
                </form>

                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>PELANGGAN</th>
                                <th>TANGGAL PESAN</th>
                                <th>TOTAL HARGA</th>
                                <th>STATUS</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($totalPesanan > 0): ?>
                                <?php foreach ($dataPesanan as $row): ?>
                                    <tr>
                                        <td>#<?= (int) $row['id_pemesanan']; ?></td>
                                        <td><strong><?= e($row['nama_pelanggan']); ?></strong></td>
                                        <td><?= e(date('d/m/Y H:i', strtotime((string) $row['tanggal_pesan']))); ?></td>
                                        <td><?= e(rupiahFormat($row['total_harga'])); ?></td>
                                        <td><span class="order-status <?= e(strtolower($row['status_pesanan'])); ?>"><?= e($row['status_pesanan']); ?></span></td>
                                        <td>
                                            <div class="menu-action">
                                                <a href="pesanan.php?edit=<?= (int) $row['id_pemesanan']; ?>" class="menu-edit">Edit</a>
                                                <form action="pesanan.php" method="POST" onsubmit="return confirm('Yakin ingin menghapus pesanan ini? Rincian dan transaksi terkait juga ikut terhapus.')">
                                                    <input type="hidden" name="csrf" value="<?= e($csrf); ?>">
                                                    <input type="hidden" name="id_pemesanan" value="<?= (int) $row['id_pemesanan']; ?>">
                                                    <button type="submit" name="hapus" class="menu-delete">Hapus</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="menu-empty">Belum ada data pesanan<?= ($q !== '' || $filterStatus !== '') ? ' yang cocok dengan filter' : ''; ?>.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </section>

        <footer class="dashboard-footer">DAFFOOD <span>•</span> Sistem Manajemen Restoran</footer>
    </main>
</div>

<script src="js/common.js"></script>
<script>
// Jam & tanggal
function updateClock() {
    const now = new Date();
    document.getElementById('live-date').textContent = now.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short', year: '2-digit' });
    document.getElementById('live-clock').textContent = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}
updateClock();
setInterval(updateClock, 1000);

// Tema gelap dan warna (tersimpan di localStorage, sama seperti halaman lain)
const themeToggle = document.getElementById('theme-toggle');
const colorTheme = document.getElementById('color-theme');
function applyThemeSettings() {
    let mode = 'light', color = 'blue';
    try { mode = localStorage.getItem('daffood-theme-mode') || 'light'; color = localStorage.getItem('daffood-color-theme') || 'blue'; } catch (e) {}
    document.body.dataset.mode = mode;
    document.body.dataset.colorTheme = color;
    themeToggle.textContent = mode === 'dark' ? '☀ Terang' : '🌙 Gelap';
    themeToggle.setAttribute('aria-pressed', String(mode === 'dark'));
    colorTheme.value = color;
}
applyThemeSettings();
themeToggle.addEventListener('click', () => {
    try { localStorage.setItem('daffood-theme-mode', (document.body.dataset.mode || 'light') === 'dark' ? 'light' : 'dark'); } catch (e) {}
    applyThemeSettings();
});
colorTheme.addEventListener('change', () => {
    try { localStorage.setItem('daffood-color-theme', colorTheme.value); } catch (e) {}
    applyThemeSettings();
});
</script>
</body>
</html>
