# DAFFOOD - Praktikum BAB 8

Lanjutan project DAFFOOD dari BAB 7. Fitur registrasi/login dan CRUD Menu (`tb_menu`) dari BAB 7 tetap dipertahankan. BAB 8 menambahkan CRUD data baru, widget jumlah data di dashboard, dan cetak PDF.

## Ketentuan Tugas dan Penerapannya

### 1. CRUD pada data selain tugas bab sebelumnya
BAB 7 mengelola `tb_menu`. Pada BAB 8, CRUD dibuat untuk **data Pemesanan (`tb_pemesanan`)** di halaman `pesanan.php` (sidebar: **Manajemen Pesanan**).
- Create: form Tambah Pesanan Baru (nama pelanggan, tanggal pesan, total harga, status).
- Read: tabel Daftar Pesanan dari database, dengan pencarian nama/ID dan filter status.
- Update: tombol Edit, ubah data, lalu Simpan Perubahan.
- Delete: tombol Hapus dengan konfirmasi (rincian pesanan dan transaksi terkait ikut terhapus karena relasi `ON DELETE CASCADE`).
- Semua query memakai PDO prepared statement, ada validasi input di server, token CSRF pada form, dan halaman hanya bisa dibuka setelah login.

### 2. Widget jumlah data di dashboard admin
Di `dashboard.php` (menu **Ringkasan**) ada 5 widget yang menampilkan jumlah baris tiap tabel: `tb_menu`, `tb_pemesanan`, `tb_detail_pemesanan`, `tb_transaksi`, dan `tb_user`. Angkanya dihitung langsung dari database memakai `SELECT COUNT(*)`, jadi ikut berubah saat data ditambah atau dihapus.

### 3. Cetak data ke PDF
Data yang dicetak: **data Pemesanan**. Tombol **Cetak PDF** dan **Unduh PDF** ada di halaman Manajemen Pesanan, dan tombol pintasan **Cetak PDF pesanan** ada di dashboard. Hasil PDF mengikuti filter yang sedang aktif (pencarian dan status), berisi judul, nama admin pencetak, tanggal cetak, tabel data, jumlah pesanan, total nilai (tidak termasuk status Batal), dan nomor halaman. File dibuat oleh `cetak_pesanan.php` memakai `lib/SimplePdf.php` (PHP murni, tidak perlu composer atau library tambahan).

## Cara Instalasi dan Menjalankan (XAMPP)
1. Ekstrak folder `TUGASPEMWEBPRAKBAB8` ke `C:\xampp\htdocs\`.
2. Jalankan **Apache** dan **MySQL** dari XAMPP Control Panel.
3. Buka `http://localhost/phpmyadmin`, buat database `db_daffood` (jika belum ada), pilih menu **Import**, lalu pilih file `db_daffood_bab8.sql`. File ini berisi semua tabel DAFFOOD, tabel `tb_user`, dan beberapa data contoh pesanan.
4. Periksa koneksi di `db.php`. Default XAMPP: host `localhost`, database `db_daffood`, user `root`, password kosong.
5. Buka `http://localhost/TUGASPEMWEBPRAKBAB8/index.php`.
6. Daftar akun lewat halaman Register, lalu masuk ke dashboard.
7. Lihat widget di halaman Ringkasan. Klik **Manajemen Pesanan** untuk mencoba tambah, edit, hapus, dan cari data. Klik **Cetak PDF** untuk membuat laporan.

Catatan: jika database `db_daffood` sudah pernah diimpor dari BAB 7, import ulang `db_daffood_bab8.sql` akan memunculkan error tabel sudah ada. Cukup hapus dulu database lamanya, atau jalankan hanya bagian `INSERT IGNORE` di akhir file untuk menambah data contoh pesanan.

## File yang Ditambahkan atau Diubah untuk BAB 8
- `pesanan.php` (baru): CRUD tabel `tb_pemesanan`.
- `cetak_pesanan.php` (baru): membuat PDF data pemesanan.
- `lib/SimplePdf.php` (baru): pembuat PDF sederhana.
- `lib/pesanan.php` (baru): fungsi bersama untuk mengambil data pesanan.
- `css/crud.css` (baru): gaya halaman CRUD.
- `dashboard.php` (diubah): widget jumlah data tabel, tautan Manajemen Pesanan, tombol cetak PDF.
- `css/style.css` (diubah): gaya widget.
- `menu.php` (diubah): tautan sidebar Manajemen Pesanan.
- `db_daffood_bab8.sql` (diubah dari BAB 7): ditambah data contoh pesanan.

## Penanda Komentar Kode
Logika baru untuk ketentuan tugas diberi komentar dengan awalan **`TUGAS BAB 8`**.

## Catatan
- Tidak ada akun contoh atau password default; registrasi harus dilakukan terlebih dahulu.
- Pastikan ekstensi PHP PDO MySQL aktif di XAMPP.
