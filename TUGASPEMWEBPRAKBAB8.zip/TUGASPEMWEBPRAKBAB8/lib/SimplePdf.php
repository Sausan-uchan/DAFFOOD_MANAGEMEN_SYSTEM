<?php
// TUGAS BAB 8 - Pembuat PDF sederhana (PHP murni, tanpa library tambahan) untuk fitur cetak laporan.
// Mendukung halaman A4, teks (Helvetica), garis, kotak berwarna, dan banyak halaman.
class SimplePdf
{
    public const W = 595.28; // lebar A4 (pt)
    public const H = 841.89; // tinggi A4 (pt)

    private array $pages = [];
    private int $cur = -1;
    private bool $bold = false;
    private float $size = 10;

    // Lebar karakter Helvetica (ASCII 32-126) dalam satuan 1/1000 em.
    private const REG = [278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,
        556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,
        667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,
        278,278,278,469,556,333,
        556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,
        334,260,334,584];
    // Lebar karakter Helvetica-Bold.
    private const BLD = [278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,
        556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,
        722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,
        333,278,333,584,556,333,
        556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,
        389,280,389,584];

    public function addPage(): void
    {
        $this->pages[] = '';
        $this->cur = count($this->pages) - 1;
    }

    // Pindah ke halaman tertentu (mulai dari 1), berguna untuk menambah footer setelah semua halaman dibuat.
    public function setPage(int $number): void
    {
        $this->cur = $number - 1;
    }

    public function pageCount(): int
    {
        return count($this->pages);
    }

    public function setFont(bool $bold, float $size): void
    {
        $this->bold = $bold;
        $this->size = $size;
    }

    // Konversi UTF-8 ke WinAnsi (cp1252) agar karakter Latin tampil benar.
    private function enc(string $s): string
    {
        if (function_exists('iconv')) {
            $r = @iconv('UTF-8', 'windows-1252//TRANSLIT//IGNORE', $s);
            if ($r !== false) return $r;
        }
        return preg_replace('/[^\x20-\x7E]/', '?', $s);
    }

    public function width(string $s, ?float $size = null): float
    {
        $size = $size ?? $this->size;
        $table = $this->bold ? self::BLD : self::REG;
        $w = 0;
        foreach (str_split($this->enc($s)) as $ch) {
            $o = ord($ch);
            $w += ($o >= 32 && $o <= 126) ? $table[$o - 32] : 556;
        }
        return $w * $size / 1000;
    }

    // Potong teks agar muat dalam lebar tertentu (ditambah "...").
    public function fit(string $s, float $maxWidth): string
    {
        if ($this->width($s) <= $maxWidth) return $s;
        while ($s !== '' && $this->width($s . '...') > $maxWidth) {
            $s = mb_substr($s, 0, mb_strlen($s) - 1);
        }
        return $s . '...';
    }

    private function esc(string $s): string
    {
        return str_replace(['\\', '(', ')', "\r"], ['\\\\', '\\(', '\\)', ''], $this->enc($s));
    }

    private function rgb(string $hex): string
    {
        $hex = ltrim($hex, '#');
        return sprintf('%.3F %.3F %.3F', hexdec(substr($hex, 0, 2)) / 255, hexdec(substr($hex, 2, 2)) / 255, hexdec(substr($hex, 4, 2)) / 255);
    }

    // Koordinat memakai titik awal kiri-ATAS halaman (y bertambah ke bawah).
    public function text(float $x, float $y, string $s, string $color = '#000000', string $align = 'L', float $boxWidth = 0): void
    {
        $w = $this->width($s);
        if ($align === 'R') $x += $boxWidth - $w;
        elseif ($align === 'C') $x += ($boxWidth - $w) / 2;
        $py = self::H - $y;
        $this->pages[$this->cur] .= sprintf("BT /%s %.2F Tf %s rg %.2F %.2F Td (%s) Tj ET\n",
            $this->bold ? 'F2' : 'F1', $this->size, $this->rgb($color), $x, $py, $this->esc($s));
    }

    public function rect(float $x, float $y, float $w, float $h, string $fill): void
    {
        $this->pages[$this->cur] .= sprintf("%s rg %.2F %.2F %.2F %.2F re f\n", $this->rgb($fill), $x, self::H - $y - $h, $w, $h);
    }

    public function line(float $x1, float $y1, float $x2, float $y2, string $color = '#cccccc', float $weight = 0.5): void
    {
        $this->pages[$this->cur] .= sprintf("%s RG %.2F w %.2F %.2F m %.2F %.2F l S\n", $this->rgb($color), $weight, $x1, self::H - $y1, $x2, self::H - $y2);
    }

    public function output(): string
    {
        $objects = [];
        $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $kids = [];
        $n = count($this->pages);
        for ($i = 0; $i < $n; $i++) $kids[] = (6 + $i * 2) . ' 0 R';
        $objects[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . "] /Count $n >>";
        $objects[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objects[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $objects[5] = '<< /Producer (DAFFOOD) /Title (Laporan DAFFOOD) >>';
        foreach ($this->pages as $i => $content) {
            $pageObj = 6 + $i * 2;
            $contentObj = $pageObj + 1;
            $objects[$pageObj] = sprintf('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>', self::W, self::H, $contentObj);
            $objects[$contentObj] = '<< /Length ' . strlen($content) . " >>\nstream\n" . $content . 'endstream';
        }
        ksort($objects);
        $pdf = "%PDF-1.4\n";
        $offsets = [];
        foreach ($objects as $num => $body) {
            $offsets[$num] = strlen($pdf);
            $pdf .= "$num 0 obj\n$body\nendobj\n";
        }
        $xref = strlen($pdf);
        $count = count($objects) + 1;
        $pdf .= "xref\n0 $count\n0000000000 65535 f \n";
        foreach ($offsets as $off) $pdf .= sprintf("%010d 00000 n \n", $off);
        $pdf .= "trailer\n<< /Size $count /Root 1 0 R /Info 5 0 R >>\nstartxref\n$xref\n%%EOF";
        return $pdf;
    }
}
