<?php
// TUGAS BAB 8 - Fungsi bersama untuk data pemesanan (dipakai pesanan.php dan cetak_pesanan.php).
const STATUS_PESANAN = ['Pending', 'Diproses', 'Selesai', 'Batal'];

// Mengambil data tb_pemesanan dengan filter pencarian nama/ID dan status (prepared statement).
function ambilPesanan(PDO $pdo, string $q = '', string $status = ''): array
{
    $sql = 'SELECT id_pemesanan, nama_pelanggan, tanggal_pesan, total_harga, status_pesanan FROM tb_pemesanan WHERE 1=1';
    $params = [];
    if ($q !== '') {
        $sql .= ' AND (nama_pelanggan LIKE ? OR id_pemesanan = ?)';
        $params[] = '%' . $q . '%';
        $params[] = ctype_digit($q) ? (int) $q : 0;
    }
    if (in_array($status, STATUS_PESANAN, true)) {
        $sql .= ' AND status_pesanan = ?';
        $params[] = $status;
    }
    $sql .= ' ORDER BY id_pemesanan DESC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function rupiahFormat($angka): string
{
    return 'Rp' . number_format((float) $angka, 0, ',', '.');
}
