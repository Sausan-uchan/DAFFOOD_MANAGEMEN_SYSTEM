<?php
require_once __DIR__ . '/session-start.php';
// IMPLEMENTASI TUGAS BAB 5 NOMOR 2: halaman dashboard hanya dapat dibuka jika session login tersedia.
if (empty($_SESSION['logged_in']) || empty($_SESSION['user_name'])) {
    header('Location: login.php?required=1');
    exit;
}
$userName = htmlspecialchars($_SESSION['user_name'], ENT_QUOTES, 'UTF-8');
$userInitial = htmlspecialchars(strtoupper(substr($_SESSION['user_name'], 0, 1)), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#f3f7fc">
    <title>Dashboard | DAFFOOD</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="dashboard-page">
    <div class="dashboard-layout">
        <aside class="sidebar">
            <a class="sidebar-brand" href="index.php" aria-label="DAFFOOD beranda">
                <span class="brand-mark">D</span>
                <span>DAFFOOD<small>FOOD MANAGEMENT</small></span>
            </a>
            <p class="sidebar-label">MENU UTAMA</p>
            <nav class="sidebar-menu" aria-label="Navigasi utama">
                <a class="nav-link active" href="#overview"><span class="nav-icon">⌂</span>Ringkasan</a>
                <a class="nav-link" href="#menu"><span class="nav-icon">▦</span>Produk & Menu</a>
                <a class="nav-link" href="#transactions"><span class="nav-icon">▤</span>Manajemen Pesanan</a>
                <a class="nav-link" href="#reports"><span class="nav-icon">▥</span>Laporan Penjualan</a>
                <a class="nav-link" href="#inventory"><span class="nav-icon">◉</span>Pemantauan Stok</a>
            </nav>
            <div class="sidebar-bottom">
                <div class="profile-chip"><span class="profile-avatar" id="profile-avatar"><?php echo $userInitial; ?></span><span><strong id="profile-name"><?php echo $userName; ?></strong><small>Admin DAFFOOD</small></span></div>
                <a class="logout-link" href="logout.php" data-confirm="Apakah Anda yakin ingin keluar dari DAFFOOD?">Keluar <span aria-hidden="true">↗</span></a>
            </div>
        </aside>

        <main class="main-content">
            <header class="topbar">
                <div class="breadcrumb">Workspace <span>/</span> <span id="current-view-label">Ringkasan</span></div>
                <div class="dashboard-tools">
                    <!-- DOM 4: jam dan tanggal diperbarui otomatis selama dashboard terbuka. -->
                    <div class="topbar-date"><span class="status-dot"></span><span id="live-date"></span><time id="live-clock"></time></div>
                    <!-- DOM 2: tombol ini mengubah dashboard antara mode terang dan gelap. -->
                    <button class="theme-toggle" id="theme-toggle" type="button" aria-pressed="false">🌙 Gelap</button>
                    <!-- DOM 3: pilihan ini mengganti warna dasar dashboard. -->
                    <label class="theme-picker">Warna
                        <select id="color-theme" aria-label="Pilih warna tema">
                            <option value="blue">Biru</option>
                            <option value="green">Hijau</option>
                            <option value="cream">Cream</option>
                            <option value="slate">Abu-abu tua</option>
                            <option value="purple">Ungu</option>
                        </select>
                    </label>
                </div>
            </header>

            <section class="dashboard-view is-active" id="overview" aria-label="Ringkasan">
                <div class="page-intro">
                    <div><p class="eyebrow">PUSAT KENDALI DAFFOOD</p><!-- DOM 1: sapaan menyesuaikan waktu lokal saat pengguna membuka dashboard. --><h1 id="greeting-title">Selamat datang, Admin</h1><p class="intro-copy">Ringkasan operasional restoran Anda hari ini.</p></div>
                    <a class="primary-button" href="#menu"><span aria-hidden="true">＋</span> Kelola menu</a>
                </div>
                <section class="stats-grid" aria-label="Ringkasan operasional">
                    <article class="stat-card stat-blue"><span class="stat-icon">▦</span><p>Total Menu</p><strong id="stat-menu">0</strong><small>Menu tersedia</small></article>
                    <article class="stat-card stat-cyan"><span class="stat-icon">▤</span><p>Total Pesanan</p><strong id="stat-orders">0</strong><small>Transaksi tercatat</small></article>
                    <article class="stat-card stat-amber"><span class="stat-icon">◷</span><p>Perlu Diproses</p><strong id="stat-pending">0</strong><small>Pesanan menunggu</small></article>
                    <article class="stat-card stat-green"><span class="stat-icon">↗</span><p>Nilai Transaksi</p><strong id="stat-revenue">Rp0</strong><small>Total seluruh pesanan</small></article>
                </section>
            </section>

            <section class="dashboard-view" id="menu" aria-label="Produk dan menu">
                <div class="page-intro"><div><p class="eyebrow">KATALOG RESTORAN</p><h1>Produk & Menu</h1><p class="intro-copy">Kelola hidangan, kategori, harga, dan ketersediaan stok.</p></div><button class="primary-button" type="button" data-create="menu"><span aria-hidden="true">＋</span> Tambah menu</button></div>
                <section class="data-section feature-section" aria-label="Daftar produk dan menu">
                    <div class="table-toolbar"><label class="search-box"><span aria-hidden="true">⌕</span><input id="menu-search" type="search" placeholder="Cari nama atau kategori..." aria-label="Cari menu"></label><span class="table-count" id="menu-count"></span></div>
                    <div class="table-wrap"><table>
                        <thead><tr><th>Nama menu</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Status</th><th class="action-heading">Aksi</th></tr></thead>
                        <tbody id="menu-rows"></tbody>
                    </table></div>
                </section>
            </section>

            <section class="dashboard-view" id="transactions" aria-label="Manajemen pesanan">
                <div class="page-intro"><div><p class="eyebrow">OPERASIONAL PESANAN</p><h1>Manajemen Pesanan</h1><p class="intro-copy">Cari pesanan, ubah status, atau unduh transaksi.</p></div><button class="primary-button" type="button" data-create="transaction"><span aria-hidden="true">＋</span> Tambah pesanan</button></div>
                <section class="data-section feature-section" aria-label="Daftar pesanan">
                    <div class="table-toolbar transaction-toolbar">
                        <label class="search-box"><span aria-hidden="true">⌕</span><input id="transaction-search" type="search" placeholder="Cari pelanggan atau menu..." aria-label="Cari pesanan"></label>
                        <div class="transaction-tools">
                            <select class="filter-select" id="transaction-status-filter" aria-label="Filter status pesanan"><option value="">Semua status</option><option>Menunggu</option><option>Diproses</option><option>Selesai</option></select>
                            <button class="outline-button" id="export-transactions" type="button"><span aria-hidden="true">↓</span> Unduh CSV</button>
                            <span class="table-count" id="transaction-count"></span>
                        </div>
                    </div>
                    <div class="table-wrap"><table>
                        <thead><tr><th>ID pesanan</th><th>Pelanggan</th><th>Menu</th><th>Jumlah</th><th>Total</th><th>Status</th><th class="action-heading">Aksi</th></tr></thead>
                        <tbody id="transaction-rows"></tbody>
                    </table></div>
                </section>
            </section>

            <section class="dashboard-view" id="reports" aria-label="Laporan penjualan">
                <div class="page-intro"><div><p class="eyebrow">ANALISIS PENJUALAN</p><h1>Laporan Penjualan</h1><p class="intro-copy">Pantau nilai pesanan harian selama tujuh hari terakhir.</p></div></div>
                <article class="insight-panel sales-panel report-panel">
                    <div class="insight-heading"><div><p class="eyebrow">PERFORMA BISNIS</p><h2>Penjualan 7 Hari</h2><p>Nilai pesanan harian dalam satu minggu terakhir.</p></div><span class="insight-icon sales-icon">↗</span></div>
                    <div class="sales-summary"><strong id="weekly-revenue">Rp0</strong><span><b id="weekly-orders">0</b> pesanan minggu ini</span></div>
                    <div class="sales-chart" id="sales-chart" role="img" aria-label="Grafik nilai pesanan tujuh hari terakhir"></div>
                    <button class="outline-button" id="report-note-button" type="button">Tambah catatan laporan</button>
                    <p class="intro-copy" id="report-note" aria-live="polite"></p>
                </article>
            </section>

            <section class="dashboard-view" id="inventory" aria-label="Pemantauan stok">
                <div class="page-intro"><div><p class="eyebrow">KONTROL PERSEDIAAN</p><h1>Pemantauan Stok</h1><p class="intro-copy">Daftar menu yang perlu segera diisi ulang.</p></div><a class="primary-button" href="#menu">Kelola menu <span aria-hidden="true">→</span></a></div>
                <article class="insight-panel inventory-panel inventory-view-panel">
                    <div class="insight-heading"><div><p class="eyebrow">PERLU PERHATIAN</p><h2>Stok Menipis</h2><p>Menu dengan stok 5 porsi atau kurang.</p></div><span class="insight-icon inventory-icon">!</span></div>
                    <div class="stock-alert-list" id="stock-alert-list"></div>
                    <a class="text-link" href="#menu">Buka pengelolaan menu <span aria-hidden="true">→</span></a>
                </article>
            </section>
            <footer class="dashboard-footer">DAFFOOD <span>•</span> Sistem Manajemen Restoran</footer>
        </main>
    </div>

    <dialog class="form-dialog" id="data-dialog" aria-labelledby="dialog-title">
        <form id="data-form">
            <div class="dialog-heading"><div><p class="eyebrow">FORMULIR DATA</p><h2 id="dialog-title">Tambah data</h2></div><button class="icon-button" type="button" id="dialog-close" aria-label="Tutup">×</button></div>
            <div class="dialog-fields" id="dialog-fields"></div>
            <div class="dialog-actions"><button class="secondary-button" type="button" id="dialog-cancel">Batal</button><button class="primary-button" type="submit">Simpan data</button></div>
        </form>
    </dialog>
    <div class="toast" id="toast" role="status" aria-live="polite"></div>

    <script src="js/common.js"></script>
    <script>
        const initialMenu = [
            { id: 'm1', name: 'Nasi Ayam Bakar', category: 'Makanan utama', price: 28000, stock: 18 },
            { id: 'm2', name: 'Soto Betawi', category: 'Makanan utama', price: 32000, stock: 12 },
            { id: 'm3', name: 'Es Kopi Susu', category: 'Minuman', price: 18000, stock: 24 },
            { id: 'm4', name: 'Pisang Goreng', category: 'Camilan', price: 16000, stock: 15 }
        ];
        const dateKey = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
        const dateForDaysAgo = (daysAgo) => {
            const date = new Date();
            date.setHours(12, 0, 0, 0);
            date.setDate(date.getDate() - daysAgo);
            return dateKey(date);
        };
        const initialTransactions = [
            { id: 'DF-2401', customer: 'Nadia Putri', menuId: 'm1', quantity: 2, status: 'Diproses', createdAt: dateForDaysAgo(0) },
            { id: 'DF-2402', customer: 'Rizky Pratama', menuId: 'm3', quantity: 1, status: 'Selesai', createdAt: dateForDaysAgo(1) },
            { id: 'DF-2403', customer: 'Dewi Anggraini', menuId: 'm2', quantity: 1, status: 'Menunggu', createdAt: dateForDaysAgo(3) },
            { id: 'DF-2404', customer: 'Bima Saputra', menuId: 'm4', quantity: 3, status: 'Diproses', createdAt: dateForDaysAgo(5) }
        ];
        const readData = (key, fallback) => {
            try { return JSON.parse(localStorage.getItem(key)) || fallback; }
            catch { return fallback; }
        };
        let menuItems = readData('daffood-menu', initialMenu);
        let transactions = readData('daffood-transactions', initialTransactions).map((item) => ({ ...item, createdAt: item.createdAt || dateForDaysAgo(0), stockDeducted: Boolean(item.stockDeducted) }));
        let activeType = '';
        let editingId = null;
        let toastTimer;
        const lowStockThreshold = 5;
        let reportNote = '';

        const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
        const rupiah = (value) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(value);
        const persist = () => {
            localStorage.setItem('daffood-menu', JSON.stringify(menuItems));
            localStorage.setItem('daffood-transactions', JSON.stringify(transactions));
        };
        const menuById = (id) => menuItems.find((item) => item.id === id);
        const showToast = (message, type = 'success') => {
            const toast = document.getElementById('toast');
            toast.textContent = message;
            toast.classList.toggle('toast-error', type === 'error');
            toast.classList.add('visible');
            clearTimeout(toastTimer);
            toastTimer = setTimeout(() => toast.classList.remove('visible'), 2600);
        };
        // TUGAS BAB 4 - Web Storage mempertahankan catatan operasional laporan di perangkat pengguna.
        try {
            reportNote = localStorage.getItem('daffood-report-note') || '';
        } catch (error) {
            showToast('Catatan laporan tidak dapat dibaca dari penyimpanan browser.', 'error');
        }
        // DOM 1: ubah sapaan sesuai waktu lokal pengguna.
        function updateGreeting() {
            const hour = new Date().getHours();
            const greeting = hour < 11 ? 'Selamat pagi' : hour < 15 ? 'Selamat siang' : hour < 18 ? 'Selamat sore' : 'Selamat malam';
            const name = document.getElementById('profile-name').textContent;
            document.getElementById('greeting-title').textContent = `${greeting}, ${name}`;
        }

// IMPLEMENTASI TUGAS BAB 5: nama dan inisial profil diambil dari PHP Session pada server.
        // DOM 2 dan DOM 3: simpan preferensi tampilan dan terapkan ke halaman.
        const colorTheme = document.getElementById('color-theme');
        const themeToggle = document.getElementById('theme-toggle');
        const availableColorThemes = ['blue', 'green', 'cream', 'slate', 'purple'];
        const savedMode = localStorage.getItem('daffood-theme-mode');
        const savedColorTheme = localStorage.getItem('daffood-color-theme');
        function applyAppearance(mode, color) {
            document.body.dataset.mode = mode;
            document.body.dataset.colorTheme = color;
            themeToggle.textContent = mode === 'dark' ? '☀ Terang' : '🌙 Gelap';
            themeToggle.setAttribute('aria-pressed', String(mode === 'dark'));
            colorTheme.value = color;
        }
        let currentMode = savedMode === 'dark' ? 'dark' : 'light';
        let currentColorTheme = availableColorThemes.includes(savedColorTheme) ? savedColorTheme : 'blue';
        applyAppearance(currentMode, currentColorTheme);
        themeToggle.addEventListener('click', () => {
            currentMode = currentMode === 'dark' ? 'light' : 'dark';
            applyAppearance(currentMode, currentColorTheme);
            try {
                localStorage.setItem('daffood-theme-mode', currentMode);
            } catch (error) {
                showToast('Preferensi tema tidak dapat disimpan.', 'error');
            }
        });
        colorTheme.addEventListener('change', () => {
            currentColorTheme = colorTheme.value;
            document.body.dataset.colorTheme = currentColorTheme;
            try {
                localStorage.setItem('daffood-color-theme', currentColorTheme);
            } catch (error) {
                showToast('Preferensi warna tidak dapat disimpan.', 'error');
            }
        });

        // DOM 4: tampilkan tanggal dan jam lokal secara langsung.
        function updateClock() {
            const now = new Date();
            document.getElementById('live-date').textContent = now.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short' });
            document.getElementById('live-clock').textContent = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateGreeting();
        updateClock();
        setInterval(updateGreeting, 60_000);
        setInterval(updateClock, 1_000);
        const actionButtons = (type, id) => `<div class="row-actions"><button class="icon-button edit-button" type="button" data-edit="${type}" data-id="${escapeHtml(id)}" aria-label="Edit">✎</button><button class="icon-button delete-button" type="button" data-delete="${type}" data-id="${escapeHtml(id)}" aria-label="Hapus">×</button></div>`;
        const compactRupiah = (value) => value >= 1000000 ? `${(value / 1000000).toFixed(1)} jt` : value >= 1000 ? `${Math.round(value / 1000)} rb` : String(value);

        function getFilteredTransactions() {
            const query = document.getElementById('transaction-search').value.toLocaleLowerCase('id');
            const status = document.getElementById('transaction-status-filter').value;
            return transactions.filter((item) => {
                const matchesQuery = `${item.id} ${item.customer} ${menuById(item.menuId)?.name || ''}`.toLocaleLowerCase('id').includes(query);
                return matchesQuery && (!status || item.status === status);
            });
        }

        function renderInsights() {
            const salesDays = Array.from({ length: 7 }, (_, index) => {
                const date = new Date();
                date.setHours(12, 0, 0, 0);
                date.setDate(date.getDate() - 6 + index);
                return { key: dateKey(date), label: date.toLocaleDateString('id-ID', { weekday: 'short' }), fullDate: date.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }), revenue: 0, orders: 0 };
            });
            const salesByDate = new Map(salesDays.map((day) => [day.key, day]));
            transactions.forEach((item) => {
                const day = salesByDate.get(item.createdAt);
                if (!day) return;
                day.revenue += (menuById(item.menuId)?.price || 0) * item.quantity;
                day.orders += 1;
            });
            const weeklyRevenue = salesDays.reduce((sum, day) => sum + day.revenue, 0);
            const weeklyOrders = salesDays.reduce((sum, day) => sum + day.orders, 0);
            const peakRevenue = Math.max(...salesDays.map((day) => day.revenue), 1);
            document.getElementById('weekly-revenue').textContent = rupiah(weeklyRevenue);
            document.getElementById('weekly-orders').textContent = weeklyOrders;
            document.getElementById('sales-chart').innerHTML = salesDays.map((day) => {
                const height = day.revenue ? Math.max(8, day.revenue / peakRevenue * 100) : 0;
                return `<div class="sales-day" title="${day.fullDate}: ${rupiah(day.revenue)}"><span class="bar-value">${day.revenue ? compactRupiah(day.revenue) : ' '}</span><div class="bar-track"><span class="sales-bar" style="height: ${height}%"></span></div><span class="day-label">${day.label}</span></div>`;
            }).join('');

            const lowStockItems = menuItems.filter((item) => Number(item.stock) <= lowStockThreshold).sort((first, second) => first.stock - second.stock);
            document.getElementById('stock-alert-list').innerHTML = lowStockItems.length ? lowStockItems.slice(0, 4).map((item) => `<div class="stock-alert-item"><span class="stock-alert-mark">!</span><span class="stock-alert-name"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.category)}</small></span><span class="stock-quantity">${item.stock} porsi</span></div>`).join('') : '<div class="stock-clear"><span>✓</span><p>Stok aman.<small>Tidak ada menu yang perlu diisi ulang.</small></p></div>';
        }

        function exportTransactions() {
            const filtered = getFilteredTransactions();
            if (!filtered.length) {
                showToast('Tidak ada pesanan untuk diekspor.');
                return;
            }
            const rows = [['ID Pesanan', 'Tanggal', 'Pelanggan', 'Menu', 'Jumlah', 'Harga Satuan', 'Total', 'Status']];
            filtered.forEach((item) => {
                const menu = menuById(item.menuId);
                rows.push([item.id, item.createdAt, item.customer, menu?.name || 'Menu dihapus', item.quantity, menu?.price || 0, (menu?.price || 0) * item.quantity, item.status]);
            });
            const csv = '\uFEFF' + rows.map((row) => row.map((value) => {
                const text = String(value ?? '');
                const spreadsheetSafe = /^[=+\-@]/.test(text) ? `'${text}` : text;
                return `"${spreadsheetSafe.replace(/"/g, '""')}"`;
            }).join(',')).join('\r\n');
            const file = new Blob([csv], { type: 'text/csv;charset=utf-8' });
            const url = URL.createObjectURL(file);
            const link = document.createElement('a');
            link.href = url;
            link.download = `daffood-pesanan-${dateForDaysAgo(0)}.csv`;
            link.click();
            URL.revokeObjectURL(url);
            showToast(`${filtered.length} pesanan berhasil diekspor.`);
        }

        const dashboardViewLabels = {
            overview: 'Ringkasan',
            menu: 'Produk & Menu',
            transactions: 'Manajemen Pesanan',
            reports: 'Laporan Penjualan',
            inventory: 'Pemantauan Stok'
        };

        function activateDashboardView(viewId) {
            const activeView = document.getElementById(viewId);
            if (!activeView?.classList.contains('dashboard-view')) return;
            document.querySelectorAll('.dashboard-view').forEach((view) => {
                const isActive = view === activeView;
                view.classList.toggle('is-active', isActive);
                view.setAttribute('aria-hidden', String(!isActive));
            });
            document.querySelectorAll('.nav-link').forEach((link) => {
                const isActive = link.hash === `#${viewId}`;
                link.classList.toggle('active', isActive);
                if (isActive) link.setAttribute('aria-current', 'page');
                else link.removeAttribute('aria-current');
            });
            document.getElementById('current-view-label').textContent = dashboardViewLabels[viewId];
        }

        function navigateToView(viewId) {
            if (!document.getElementById(viewId)?.classList.contains('dashboard-view')) return;
            if (window.location.hash !== `#${viewId}`) window.location.hash = viewId;
            activateDashboardView(viewId);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        function renderDashboard() {
            const menuQuery = document.getElementById('menu-search').value.toLocaleLowerCase('id');
            const menuFiltered = menuItems.filter((item) => `${item.name} ${item.category}`.toLocaleLowerCase('id').includes(menuQuery));
            document.getElementById('menu-rows').innerHTML = menuFiltered.length ? menuFiltered.map((item) => `<tr><td><span class="item-name">${escapeHtml(item.name)}</span></td><td>${escapeHtml(item.category)}</td><td class="price-cell">${rupiah(item.price)}</td><td>${item.stock} porsi</td><td><span class="badge ${item.stock > 0 ? 'badge-available' : 'badge-empty'}">${item.stock > 0 ? 'Tersedia' : 'Habis'}</span></td><td>${actionButtons('menu', item.id)}</td></tr>`).join('') : '<tr><td class="empty-state" colspan="6">Menu tidak ditemukan.</td></tr>';
            document.getElementById('menu-count').textContent = `${menuFiltered.length} dari ${menuItems.length} menu`;

            const transactionFiltered = getFilteredTransactions();
            document.getElementById('transaction-rows').innerHTML = transactionFiltered.length ? transactionFiltered.map((item) => {
                const menu = menuById(item.menuId);
                const total = (menu?.price || 0) * item.quantity;
                const statusClass = item.status === 'Selesai' ? 'badge-done' : item.status === 'Diproses' ? 'badge-progress' : 'badge-pending';
                return `<tr><td><span class="order-id">#${escapeHtml(item.id)}</span></td><td><span class="item-name">${escapeHtml(item.customer)}</span></td><td>${escapeHtml(menu?.name || 'Menu dihapus')}</td><td>${item.quantity}</td><td class="price-cell">${rupiah(total)}</td><td><span class="badge ${statusClass}">${escapeHtml(item.status)}</span></td><td>${actionButtons('transaction', item.id)}</td></tr>`;
            }).join('') : '<tr><td class="empty-state" colspan="7">Pesanan tidak ditemukan.</td></tr>';
            document.getElementById('transaction-count').textContent = `${transactionFiltered.length} dari ${transactions.length} pesanan`;

            document.getElementById('stat-menu').textContent = menuItems.length;
            document.getElementById('stat-orders').textContent = transactions.length;
            document.getElementById('stat-pending').textContent = transactions.filter((item) => item.status === 'Menunggu').length;
            document.getElementById('stat-revenue').textContent = rupiah(transactions.reduce((sum, item) => sum + (menuById(item.menuId)?.price || 0) * item.quantity, 0));
            renderInsights();
            document.getElementById('report-note').textContent = reportNote ? `Catatan: ${reportNote}` : '';
        }

        function openDialog(type, id = null) {
            activeType = type;
            editingId = id;
            const record = id ? (type === 'menu' ? menuById(id) : transactions.find((item) => item.id === id)) : null;
            const fields = document.getElementById('dialog-fields');
            document.getElementById('dialog-title').textContent = `${record ? 'Edit' : 'Tambah'} ${type === 'menu' ? 'menu' : 'pesanan'}`;
            if (type === 'menu') {
                fields.innerHTML = `<label>Nama menu<input name="name" type="text" value="${escapeHtml(record?.name || '')}" placeholder="Contoh: Nasi Goreng" required maxlength="60"></label><label>Kategori<input name="category" type="text" value="${escapeHtml(record?.category || '')}" placeholder="Contoh: Makanan utama" required maxlength="40"></label><div class="field-row"><label>Harga (Rp)<input name="price" type="number" min="1" step="500" value="${record?.price || ''}" placeholder="25000" required></label><label>Stok (porsi)<input name="stock" type="number" min="0" step="1" value="${record?.stock ?? ''}" placeholder="10" required></label></div>`;
            } else {
                const options = menuItems.map((item) => `<option value="${escapeHtml(item.id)}" ${record?.menuId === item.id ? 'selected' : ''}>${escapeHtml(item.name)} - ${rupiah(item.price)}</option>`).join('');
                fields.innerHTML = `<label>Nama pelanggan<input name="customer" type="text" value="${escapeHtml(record?.customer || '')}" placeholder="Nama pelanggan" required maxlength="60"></label><div class="field-row"><label>Menu<select name="menuId" required ${menuItems.length ? '' : 'disabled'}>${menuItems.length ? options : '<option value="">Tambahkan menu terlebih dahulu</option>'}</select></label><label>Jumlah<input name="quantity" type="number" min="1" step="1" value="${record?.quantity || 1}" required></label></div><label>Status pesanan<select name="status"><option ${record?.status === 'Menunggu' ? 'selected' : ''}>Menunggu</option><option ${record?.status === 'Diproses' || !record ? 'selected' : ''}>Diproses</option><option ${record?.status === 'Selesai' ? 'selected' : ''}>Selesai</option></select></label>`;
            }
            document.getElementById('data-dialog').showModal();
            fields.querySelector('input, select')?.focus();
        }

        document.querySelectorAll('[data-create]').forEach((button) => button.addEventListener('click', () => openDialog(button.dataset.create)));
        document.getElementById('dialog-close').addEventListener('click', () => document.getElementById('data-dialog').close());
        document.getElementById('dialog-cancel').addEventListener('click', () => document.getElementById('data-dialog').close());
        document.getElementById('menu-search').addEventListener('input', renderDashboard);
        document.getElementById('transaction-search').addEventListener('input', renderDashboard);
        document.getElementById('transaction-status-filter').addEventListener('change', renderDashboard);
        document.getElementById('export-transactions').addEventListener('click', exportTransactions);
        // TUGAS BAB 4 - Popup Box prompt meminta catatan; alert memberi umpan balik bila kosong atau gagal disimpan.
        document.getElementById('report-note-button').addEventListener('click', () => {
            const note = window.prompt('Masukkan catatan untuk laporan penjualan DAFFOOD:', reportNote);
            if (note === null) return;
            if (!note.trim()) {
                window.alert('Catatan laporan tidak boleh kosong.');
                return;
            }
            try {
                reportNote = note.trim();
                localStorage.setItem('daffood-report-note', reportNote);
                document.getElementById('report-note').textContent = `Catatan: ${reportNote}`;
                showToast('Catatan laporan berhasil disimpan.');
            } catch (error) {
                window.alert('Catatan laporan gagal disimpan ke browser.');
            }
        });
        document.querySelectorAll('a[href^="#"]').forEach((link) => link.addEventListener('click', (event) => {
            const viewId = link.getAttribute('href').slice(1);
            if (!document.getElementById(viewId)?.classList.contains('dashboard-view')) return;
            event.preventDefault();
            navigateToView(viewId);
        }));
        // TUGAS BAB 4 - Event hashchange memperbarui tampilan saat navigasi dan tombol kembali/maju digunakan.
        window.addEventListener('hashchange', () => activateDashboardView(window.location.hash.slice(1) || 'overview'));
        activateDashboardView(window.location.hash.slice(1) || 'overview');
        document.getElementById('data-form').addEventListener('submit', async (event) => {
            // TUGAS BAB 4 - Event submit menggunakan Promise sebelum data menu/pesanan disimpan.
            event.preventDefault();
            const submitButton = event.currentTarget.querySelector('[type="submit"]');
            submitButton.disabled = true;
            await DAFFOOD.wait(200);
            const previousMenuItems = JSON.parse(JSON.stringify(menuItems));
            const previousTransactions = JSON.parse(JSON.stringify(transactions));
            const values = Object.fromEntries(new FormData(event.currentTarget));
            if (activeType === 'menu') {
                const record = { id: editingId || `menu-${Date.now()}`, name: values.name.trim(), category: values.category.trim(), price: Number(values.price), stock: Number(values.stock) };
                if (editingId) menuItems = menuItems.map((item) => item.id === editingId ? record : item);
                else menuItems.unshift(record);
            } else {
                const existing = editingId ? transactions.find((item) => item.id === editingId) : null;
                const selectedMenu = menuById(values.menuId);
                const existingMenu = existing ? menuById(existing.menuId) : null;
                const returnedQuantity = existing?.stockDeducted && existing.menuId === values.menuId ? existing.quantity : 0;
                const quantity = Number(values.quantity);
                if (!selectedMenu || quantity > Number(selectedMenu.stock) + returnedQuantity) {
                    showToast('Stok menu tidak cukup untuk jumlah pesanan.', 'error');
                    submitButton.disabled = false;
                    return;
                }
                if (existing?.stockDeducted && existingMenu) existingMenu.stock += existing.quantity;
                selectedMenu.stock -= quantity;
                const record = { id: editingId || `DF-${String(Date.now()).slice(-6)}`, customer: values.customer.trim(), menuId: values.menuId, quantity, status: values.status, createdAt: existing?.createdAt || dateForDaysAgo(0), stockDeducted: true };
                if (editingId) transactions = transactions.map((item) => item.id === editingId ? record : item);
                else transactions.unshift(record);
            }
            try {
                persist();
            } catch (error) {
                menuItems = previousMenuItems;
                transactions = previousTransactions;
                renderDashboard();
                showToast('Data gagal disimpan ke penyimpanan browser.', 'error');
                submitButton.disabled = false;
                return;
            }
            renderDashboard();
            document.getElementById('data-dialog').close();
            submitButton.disabled = false;
            showToast(`${activeType === 'menu' ? 'Menu' : 'Pesanan'} berhasil ${editingId ? 'diperbarui' : 'ditambahkan'}.`);
        });
        document.addEventListener('click', (event) => {
            const target = event.target instanceof Element ? event.target : null;
            if (!target) return;
            const editButton = target.closest('[data-edit]');
            const deleteButton = target.closest('[data-delete]');
            if (editButton) openDialog(editButton.dataset.edit, editButton.dataset.id);
            else if (deleteButton) {
                const { delete: type, id } = deleteButton.dataset;
                const label = type === 'menu' ? menuById(id)?.name : `pesanan #${id}`;
                if (!window.confirm(`Apakah Anda yakin ingin menghapus ${label}?`)) return;
                const previousMenuItems = JSON.parse(JSON.stringify(menuItems));
                const previousTransactions = JSON.parse(JSON.stringify(transactions));
                if (type === 'menu') menuItems = menuItems.filter((item) => item.id !== id);
                else {
                    const transaction = transactions.find((item) => item.id === id);
                    const menu = transaction?.stockDeducted ? menuById(transaction.menuId) : null;
                    if (menu) menu.stock += transaction.quantity;
                    transactions = transactions.filter((item) => item.id !== id);
                }
                try {
                    persist();
                } catch (error) {
                    menuItems = previousMenuItems;
                    transactions = previousTransactions;
                    renderDashboard();
                    showToast('Data gagal disimpan ke penyimpanan browser.', 'error');
                    return;
                }
                renderDashboard();
                showToast('Data berhasil dihapus.');
            }
        });
        renderDashboard();
    </script>
</body>
</html>