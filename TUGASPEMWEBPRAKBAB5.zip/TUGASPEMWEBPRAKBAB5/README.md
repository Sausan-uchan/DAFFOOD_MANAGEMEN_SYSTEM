# DAFFOOD - Sistem Manajemen Restoran

## Implementasi Tugas Praktikum BAB 5 Nomor 1 dan 2

Project DAFFOOD dari tugas sebelumnya telah disesuaikan agar berjalan menggunakan PHP dan PHP Session.

### 1. Penerapan PHP
- Halaman `index.html`, `login.html`, `register.html`, `dashboard.html`, dan `toast.html` diubah menjadi file PHP.
- Seluruh tautan navigasi dan tujuan form disesuaikan ke ekstensi `.php`.
- File `session-start.php` digunakan untuk memulai session pada halaman yang membutuhkan identitas pengguna.
- `login.php`, `register.php`, dan `logout.php` memproses data menggunakan PHP.

### 2. Penerapan Session / Cookie
- Form registrasi menerima nama dan email pengguna.
- PHP menyimpan nama, email, dan status login ke `$_SESSION` pada server.
- `dashboard.php` membaca nama pengguna dari session dan menampilkannya pada profil dashboard.
- `dashboard.php` dilindungi pemeriksaan session. Jika belum login, pengguna diarahkan ke `login.php`.
- Tombol **Keluar** pada dashboard mengarah ke `logout.php`. Setelah konfirmasi, session dihapus dengan `session_unset()` dan `session_destroy()`.

> Catatan: project ini merupakan implementasi praktikum session, belum memakai database maupun autentikasi password permanen. Form login menerima input email dan kata sandi untuk simulasi alur session; jangan gunakan untuk akun atau kata sandi sungguhan.

## Cara Menjalankan
1. Ekstrak folder `TUGASPEMWEBPRAK- BAB4` ke `C:\laragon\www\` (Laragon) atau `C:\xampp\htdocs\` (XAMPP).
2. Jalankan Apache melalui Laragon atau XAMPP.
3. Buka `http://localhost/TUGASPEMWEBPRAK-%20BAB4/` atau `http://localhost/TUGASPEMWEBPRAK-%20BAB4/index.php`.
4. Pilih **Mulai sekarang**, isi nama, email, kata sandi, lalu tekan **Buat akun**. Sistem akan menyimpan nama ke PHP Session dan membuka dashboard.
5. Nama pengguna tampil pada profil di bagian kiri dashboard.
6. Tekan **Keluar** dan setujui konfirmasi. Session dihapus dan pengguna kembali ke halaman login.
7. Coba akses `dashboard.php` setelah logout. Sistem akan mengarahkan kembali ke login karena session sudah tidak tersedia.

## Catatan Struktur
- `session-start.php`: inisialisasi session.
- `register.php`: menerima data registrasi dan menyimpan identitas ke session.
- `login.php`: memproses form login dan membuat session.
- `dashboard.php`: halaman utama yang dilindungi session.
- `logout.php`: menghapus session.
- `css/style.css` dan `js/common.js`: aset tampilan dan interaksi project sebelumnya tetap digunakan.
